export interface ChatMessage {
  id: string
  text: string
  sender: "user" | "support"
  timestamp: Date
}

export async function sendChatMessage(userMessage: string): Promise<string> {
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message: userMessage,
      }),
    })

    if (!response.ok) {
      throw new Error("Failed to get response from support")
    }

    const data = await response.json()
    return data.message || data.reply || "I'm having trouble processing your request. Please try again."
  } catch (error) {
    console.error("[v0] Chat service error:", error)
    return "I'm having trouble processing your request right now. Please try again or email us at support@morganwallenlive.com"
  }
}

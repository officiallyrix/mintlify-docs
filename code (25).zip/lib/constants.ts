// Application-wide constants

export const APP_NAME = "Morgan Wallen Live"
export const APP_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000"

export const TICKET_TYPES = ["General Admission", "VIP", "Premium VIP"]

export const TICKET_STATUSES = {
  VALID: "valid",
  USED: "used",
  CANCELLED: "cancelled",
  EXPIRED: "expired",
}

export const ORDER_STATUSES = {
  PENDING: "pending",
  CONFIRMED: "confirmed",
  COMPLETED: "completed",
  CANCELLED: "cancelled",
}

export const PAYMENT_CONFIG = {
  FEE_PERCENTAGE: 0.1, // 10% fees
  CURRENCY: "USD",
  MIN_AMOUNT: 0.5, // $0.50 minimum
}

export const ADMIN_CONFIG = {
  // Change this to a secure password in production
  PASSWORD_HASH: "admin123",
  SESSION_TIMEOUT: 60 * 60 * 1000, // 1 hour
}

export const EMAIL_TEMPLATES = {
  ORDER_CONFIRMATION: "order-confirmation",
  ORDER_UPDATE: "order-update",
  TICKET_REMINDER: "ticket-reminder",
  CANCELLED_ORDER: "cancelled-order",
}

export const ERROR_MESSAGES = {
  INVALID_TICKET: "The ticket you provided is invalid or not found.",
  PAYMENT_FAILED: "Payment processing failed. Please try again.",
  ORDER_NOT_FOUND: "Order not found. Please check your confirmation number.",
  VALIDATION_ERROR: "Please check your input and try again.",
  SERVER_ERROR: "An unexpected error occurred. Please try again later.",
}

// Input validation utilities

export interface ValidationError {
  field: string
  message: string
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

export function validatePhoneNumber(phone: string): boolean {
  const phoneRegex = /^\d{10}$|^$$\d{3}$$\s?\d{3}-?\d{4}$/
  return phoneRegex.test(phone.replace(/[\s-()]/g, ""))
}

export function validateCardNumber(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, "")
  return digits.length === 16
}

export function validateCheckoutForm(data: {
  firstName: string
  lastName: string
  email: string
  phone: string
  cardNumber: string
  expiry: string
  cvv: string
}): ValidationError[] {
  const errors: ValidationError[] = []

  if (!data.firstName?.trim()) {
    errors.push({ field: "firstName", message: "First name is required" })
  }

  if (!data.lastName?.trim()) {
    errors.push({ field: "lastName", message: "Last name is required" })
  }

  if (!validateEmail(data.email)) {
    errors.push({ field: "email", message: "Invalid email address" })
  }

  if (!validatePhoneNumber(data.phone)) {
    errors.push({ field: "phone", message: "Invalid phone number" })
  }

  if (!validateCardNumber(data.cardNumber)) {
    errors.push({ field: "cardNumber", message: "Invalid card number" })
  }

  if (!data.expiry?.match(/^\d{2}\/\d{2}$/)) {
    errors.push({ field: "expiry", message: "Invalid expiry date (MM/YY)" })
  }

  if (!data.cvv?.match(/^\d{3}$/)) {
    errors.push({ field: "cvv", message: "Invalid CVV" })
  }

  return errors
}

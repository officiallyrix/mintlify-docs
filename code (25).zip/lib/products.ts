export interface TicketProduct {
  id: string
  eventId: number
  eventTitle: string
  venue: string
  date: string
  time: string
  ticketType: string
  priceInCents: number
}

export const TICKET_PRODUCTS: TicketProduct[] = [
  // US Events
  {
    id: "usa-minneapolis-1-ga",
    eventId: 1,
    eventTitle: "Morgan Wallen Live",
    venue: "U.S. Bank Stadium, Minneapolis, MN",
    date: "Apr 10, 2026",
    time: "8:00 PM",
    ticketType: "General Admission",
    priceInCents: 8900,
  },
  {
    id: "usa-minneapolis-1-vip",
    eventId: 1,
    eventTitle: "Morgan Wallen Live",
    venue: "U.S. Bank Stadium, Minneapolis, MN",
    date: "Apr 10, 2026",
    time: "8:00 PM",
    ticketType: "VIP",
    priceInCents: 15900,
  },
  {
    id: "usa-minneapolis-1-premium",
    eventId: 1,
    eventTitle: "Morgan Wallen Live",
    venue: "U.S. Bank Stadium, Minneapolis, MN",
    date: "Apr 10, 2026",
    time: "8:00 PM",
    ticketType: "Premium VIP",
    priceInCents: 24900,
  },
  // UK Events
  {
    id: "uk-london-24-ga",
    eventId: 24,
    eventTitle: "Morgan Wallen Live",
    venue: "The O2, London, UK",
    date: "Aug 15, 2026",
    time: "8:00 PM",
    ticketType: "General Admission",
    priceInCents: 9500,
  },
  {
    id: "uk-london-24-vip",
    eventId: 24,
    eventTitle: "Morgan Wallen Live",
    venue: "The O2, London, UK",
    date: "Aug 15, 2026",
    time: "8:00 PM",
    ticketType: "VIP",
    priceInCents: 17500,
  },
  {
    id: "uk-london-24-premium",
    eventId: 24,
    eventTitle: "Morgan Wallen Live",
    venue: "The O2, London, UK",
    date: "Aug 15, 2026",
    time: "8:00 PM",
    ticketType: "Premium VIP",
    priceInCents: 28500,
  },
  // Add more products as needed
]

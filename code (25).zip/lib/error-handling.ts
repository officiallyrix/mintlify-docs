// Error handling and logging utilities

export type ErrorSeverity = "low" | "medium" | "high" | "critical"

export interface AppError {
  message: string
  code: string
  severity: ErrorSeverity
  context?: Record<string, unknown>
  timestamp: string
}

export class ErrorHandler {
  static log(error: AppError): void {
    console.error(`[${error.severity.toUpperCase()}] ${error.code}: ${error.message}`)

    if (error.context) {
      console.error("Context:", error.context)
    }

    // In production, send to error tracking service
    // Example: Sentry.captureException(error)
  }

  static createError(
    message: string,
    code: string,
    severity: ErrorSeverity = "medium",
    context?: Record<string, unknown>,
  ): AppError {
    return {
      message,
      code,
      severity,
      context,
      timestamp: new Date().toISOString(),
    }
  }

  static handlePaymentError(error: unknown): AppError {
    if (error instanceof Error) {
      return this.createError("Payment processing failed", "PAYMENT_ERROR", "high", { originalError: error.message })
    }
    return this.createError("Unknown payment error", "PAYMENT_ERROR", "high")
  }

  static handleValidationError(fields: Record<string, string>): AppError {
    return this.createError("Validation failed", "VALIDATION_ERROR", "low", { fields })
  }
}

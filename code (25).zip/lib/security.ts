// Security utilities

export function sanitizeInput(input: string): string {
  return input.trim().replace(/[<>]/g, "").slice(0, 255)
}

export function hashPassword(password: string): string {
  // In production, use bcrypt or similar
  // import bcrypt from 'bcrypt'
  // return await bcrypt.hash(password, 10)
  return Buffer.from(password).toString("base64")
}

export function verifyPassword(password: string, hash: string): boolean {
  // In production, use bcrypt verification
  // import bcrypt from 'bcrypt'
  // return await bcrypt.compare(password, hash)
  return Buffer.from(hash, "base64").toString() === password
}

export function generateSecureToken(length = 32): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
  let result = ""
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

export function isValidOrigin(origin: string | undefined): boolean {
  const allowedOrigins = [
    "http://localhost:3000",
    "https://morganwallenlive.com",
    process.env.NEXT_PUBLIC_API_URL,
  ].filter(Boolean)

  return origin ? allowedOrigins.includes(origin) : false
}

export function getRateLimitKey(ip: string, endpoint: string): string {
  return `rate-limit:${ip}:${endpoint}`
}

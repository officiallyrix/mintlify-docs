// Third-party service integrations

// Stripe Payment Integration
export const stripeConfig = {
  publicKey: process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY,
  secretKey: process.env.STRIPE_SECRET_KEY,
}

// SendGrid Email Integration
export const sendGridConfig = {
  apiKey: process.env.SENDGRID_API_KEY,
  fromEmail: process.env.SENDGRID_FROM_EMAIL || "noreply@morganwallenlive.com",
}

// Resend Email Integration (Alternative to SendGrid)
export const resendConfig = {
  apiKey: process.env.RESEND_API_KEY,
  fromEmail: process.env.RESEND_FROM_EMAIL || "noreply@morganwallenlive.com",
}

// Supabase Integration
export const supabaseConfig = {
  url: process.env.NEXT_PUBLIC_SUPABASE_URL,
  anonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  serviceKey: process.env.SUPABASE_SERVICE_ROLE_KEY,
}

// QR Code Service
export const qrCodeConfig = {
  serviceUrl: process.env.QR_CODE_SERVICE_URL || "https://api.qrserver.com",
  size: 300,
}

// Analytics Integration
export const analyticsConfig = {
  vercelId: process.env.VERCEL_ANALYTICS_ID,
  enabled: process.env.NODE_ENV === "production",
}

// Check required integrations for specific features
export function checkIntegrations() {
  const integrations = {
    payment: !!stripeConfig.secretKey,
    email: !!sendGridConfig.apiKey || !!resendConfig.apiKey,
    database: !!process.env.DATABASE_URL,
    analytics: !!analyticsConfig.vercelId,
  }

  const missing = Object.entries(integrations)
    .filter(([, enabled]) => !enabled)
    .map(([name]) => name)

  if (missing.length > 0) {
    console.warn("[INTEGRATIONS] Missing integrations:", missing)
  }

  return integrations
}

// Email service for sending confirmations and notifications
// In production, integrate with SendGrid, Resend, AWS SES, etc.

interface EmailPayload {
  to: string
  subject: string
  template: string
  data: Record<string, unknown>
}

export async function sendConfirmationEmail(
  email: string,
  confirmationNumber: string,
  customerName: string,
  total: number,
): Promise<boolean> {
  try {
    // In production, use email service provider
    console.log(`[EMAIL] Sending confirmation to ${email}`)
    console.log(`[EMAIL] Confirmation Number: ${confirmationNumber}`)

    // Example integration point for SendGrid:
    // const sgMail = require('@sendgrid/mail');
    // sgMail.setApiKey(process.env.SENDGRID_API_KEY);
    // await sgMail.send({
    //   to: email,
    //   from: 'noreply@morganwallenlive.com',
    //   subject: 'Your Order Confirmation',
    //   html: renderConfirmationEmail(confirmationNumber, customerName, total),
    // });

    return true
  } catch (error) {
    console.error("[EMAIL] Error sending confirmation:", error)
    return false
  }
}

export async function sendOrderUpdateEmail(
  email: string,
  confirmationNumber: string,
  status: "confirmed" | "shipped" | "cancelled",
): Promise<boolean> {
  try {
    console.log(`[EMAIL] Sending ${status} update to ${email}`)
    return true
  } catch (error) {
    console.error("[EMAIL] Error sending order update:", error)
    return false
  }
}

export function renderConfirmationEmail(confirmationNumber: string, customerName: string, total: number): string {
  return `
    <html>
      <body>
        <h1>Order Confirmation</h1>
        <p>Dear ${customerName},</p>
        <p>Thank you for your order! Your confirmation number is: <strong>${confirmationNumber}</strong></p>
        <p>Total Amount: $${total.toFixed(2)}</p>
        <p>You can view your tickets at: <a href="#">My Tickets</a></p>
        <p>Best regards,<br>Morgan Wallen Live Team</p>
      </body>
    </html>
  `
}

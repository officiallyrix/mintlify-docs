-- Create tickets table
CREATE TABLE IF NOT EXISTS tickets (
  id SERIAL PRIMARY KEY,
  ticket_id VARCHAR(255) UNIQUE NOT NULL,
  event_id INTEGER NOT NULL,
  customer_email VARCHAR(255) NOT NULL,
  customer_name VARCHAR(255) NOT NULL,
  ticket_type VARCHAR(100) NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  status VARCHAR(50) DEFAULT 'active',
  scanned BOOLEAN DEFAULT FALSE,
  scanned_at TIMESTAMP,
  scanned_by VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CHECK (status IN ('active', 'used', 'cancelled', 'refunded'))
);

-- Create indexes for faster lookups
CREATE INDEX IF NOT EXISTS idx_ticket_id ON tickets(ticket_id);
CREATE INDEX IF NOT EXISTS idx_event_id ON tickets(event_id);
CREATE INDEX IF NOT EXISTS idx_customer_email ON tickets(customer_email);
CREATE INDEX IF NOT EXISTS idx_status ON tickets(status);

-- Create scan_logs table for audit trail
CREATE TABLE IF NOT EXISTS ticket_scan_logs (
  id SERIAL PRIMARY KEY,
  ticket_id VARCHAR(255) NOT NULL,
  scanned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  scanned_by VARCHAR(255) NOT NULL,
  scan_status VARCHAR(50) NOT NULL,
  location VARCHAR(255),
  device_info VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_scan_ticket_id ON ticket_scan_logs(ticket_id);

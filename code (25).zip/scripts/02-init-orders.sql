-- Create events table if not exists
CREATE TABLE IF NOT EXISTS events (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  artist VARCHAR(255),
  date VARCHAR(100) NOT NULL,
  time VARCHAR(50),
  location VARCHAR(255),
  capacity INTEGER,
  seats_available INTEGER,
  price NUMERIC(10, 2),
  image_url VARCHAR(500),
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create orders table if not exists
CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  confirmation_number VARCHAR(50) UNIQUE NOT NULL,
  customer_name VARCHAR(255) NOT NULL,
  customer_email VARCHAR(255) NOT NULL,
  customer_phone VARCHAR(20),
  subtotal NUMERIC(10, 2),
  fees NUMERIC(10, 2),
  total NUMERIC(10, 2) NOT NULL,
  status VARCHAR(50) DEFAULT 'confirmed',
  payment_method VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
  id SERIAL PRIMARY KEY,
  order_id INTEGER NOT NULL,
  event_id INTEGER NOT NULL,
  ticket_type VARCHAR(100) NOT NULL,
  quantity INTEGER NOT NULL,
  price NUMERIC(10, 2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- Create indexes for faster lookups
CREATE INDEX IF NOT EXISTS idx_orders_email ON orders(customer_email);
CREATE INDEX IF NOT EXISTS idx_orders_confirmation ON orders(confirmation_number);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_events_date ON events(date);

-- Insert sample Morgan Wallen event
INSERT INTO events (title, artist, date, time, location, capacity, seats_available, price, description)
VALUES (
  'Morgan Wallen Live',
  'Morgan Wallen',
  'Dec 5, 2024',
  '8:00 PM',
  'Nissan Stadium, Nashville, TN',
  40000,
  5200,
  89,
  'Experience Morgan Wallen live at Nissan Stadium in Nashville, Tennessee.'
)
ON CONFLICT DO NOTHING;

"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

export interface CartItem {
  id: string
  eventId: number
  eventTitle: string
  venue: string
  date: string
  time: string
  ticketType: string
  price: number
  quantity: number
  addedAt: number
}

interface CartContextType {
  items: CartItem[]
  addItem: (item: Omit<CartItem, "id" | "addedAt">) => void
  removeItem: (id: string) => void
  clearCart: () => void
  updateQuantity: (id: string, quantity: number) => void
}

const CartContext = createContext<CartContextType | undefined>(undefined)

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [isHydrated, setIsHydrated] = useState(false)

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("cart")
    if (saved) {
      try {
        setItems(JSON.parse(saved))
      } catch {
        setItems([])
      }
    }
    setIsHydrated(true)
  }, [])

  // Save to localStorage whenever items change
  useEffect(() => {
    if (isHydrated) {
      localStorage.setItem("cart", JSON.stringify(items))
    }
  }, [items, isHydrated])

  const addItem = (item: Omit<CartItem, "id" | "addedAt">) => {
    setItems((prev) => {
      const existingItem = prev.find((i) => i.eventId === item.eventId && i.ticketType === item.ticketType)

      if (existingItem) {
        return prev.map((i) => (i.id === existingItem.id ? { ...i, quantity: i.quantity + item.quantity } : i))
      }

      return [
        ...prev,
        {
          ...item,
          id: `${item.eventId}-${item.ticketType}-${Date.now()}`,
          addedAt: Date.now(),
        },
      ]
    })
  }

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id))
  }

  const updateQuantity = (id: string, quantity: number) => {
    setItems((prev) => prev.map((item) => (item.id === id ? { ...item, quantity: Math.max(1, quantity) } : item)))
  }

  const clearCart = () => {
    setItems([])
  }

  return (
    <CartContext.Provider value={{ items, addItem, removeItem, updateQuantity, clearCart }}>
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (!context) {
    throw new Error("useCart must be used within CartProvider")
  }
  return context
}

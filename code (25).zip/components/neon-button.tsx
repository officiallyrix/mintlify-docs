"use client"

import { Button } from "@/components/ui/button"
import type { ReactNode } from "react"

interface NeonButtonProps {
  children: ReactNode
  variant?: "primary" | "secondary" | "accent"
  size?: "sm" | "md" | "lg"
  disabled?: boolean
  onClick?: () => void
  className?: string
}

export function NeonButton({
  children,
  variant = "primary",
  size = "md",
  disabled = false,
  onClick,
  className = "",
}: NeonButtonProps) {
  const baseStyles = "relative transition-all duration-300 active:scale-95"

  const variantStyles = {
    primary: "bg-primary text-primary-foreground neon-shadow-primary",
    secondary: "bg-secondary text-secondary-foreground neon-shadow-secondary",
    accent: "bg-accent text-accent-foreground neon-shadow-accent",
  }

  const sizeMap = {
    sm: "sm",
    md: "md",
    lg: "lg",
  }

  return (
    <Button
      size={sizeMap[size]}
      disabled={disabled}
      onClick={onClick}
      className={`${baseStyles} ${variantStyles[variant]} ${className}`}
    >
      {children}
    </Button>
  )
}

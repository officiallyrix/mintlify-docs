"use client"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import Image from "next/image"

export default function Header() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <header className="sticky top-0 z-50 border-b border-border bg-background/90 backdrop-blur-md shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-14 sm:h-16">
            <Link href="/" className="flex items-center gap-2 sm:gap-3 hover:opacity-80 transition">
              <Image
                src="/mw-initials-logo.png"
                alt="Morgan Wallen Logo"
                width={50}
                height={50}
                className="h-10 sm:h-12 w-auto"
                priority
              />
              <span className="hidden sm:inline text-foreground font-bold text-base sm:text-lg">Morgan Wallen Live</span>
            </Link>

            <nav className="hidden md:flex items-center gap-4 lg:gap-8">
              <Link href="/" className="text-sm lg:text-base text-foreground hover:text-primary transition">
                Home
              </Link>
              <Link href="/events" className="text-sm lg:text-base text-foreground hover:text-primary transition">
                Events
              </Link>
              <Link href="/venue" className="text-sm lg:text-base text-foreground hover:text-primary transition">
                Venue
              </Link>
              <Link href="/tickets" className="text-sm lg:text-base text-foreground hover:text-primary transition">
                Tickets
              </Link>
              <Link href="/merchandise" className="text-sm lg:text-base text-foreground hover:text-primary transition">
                Merchandise
              </Link>
              <Link href="/about" className="text-sm lg:text-base text-foreground hover:text-primary transition">
                About
              </Link>
            </nav>

            {/* Desktop Actions */}
            <div className="hidden md:flex items-center gap-4">
              <Link href="/cart">
                <Button variant="ghost" size="sm" className="relative">
                  <span className="text-lg">🛒</span>
                </Button>
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden text-foreground hover:text-primary transition p-2"
              aria-label={isOpen ? "Close menu" : "Open menu"}
            >
              {isOpen ? <span className="text-2xl">✕</span> : <span className="text-2xl">☰</span>}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isOpen && (
            <nav className="md:hidden pb-4 flex flex-col gap-1 animate-fade-in">
              <Link href="/" className="text-foreground hover:text-primary hover:bg-muted/50 transition py-2 px-2 rounded" onClick={() => setIsOpen(false)}>
                Home
              </Link>
              <Link href="/events" className="text-foreground hover:text-primary hover:bg-muted/50 transition py-2 px-2 rounded" onClick={() => setIsOpen(false)}>
                Events
              </Link>
              <Link href="/venue" className="text-foreground hover:text-primary hover:bg-muted/50 transition py-2 px-2 rounded" onClick={() => setIsOpen(false)}>
                Venue
              </Link>
              <Link href="/tickets" className="text-foreground hover:text-primary hover:bg-muted/50 transition py-2 px-2 rounded" onClick={() => setIsOpen(false)}>
                Tickets
              </Link>
              <Link href="/merchandise" className="text-foreground hover:text-primary hover:bg-muted/50 transition py-2 px-2 rounded" onClick={() => setIsOpen(false)}>
                Merchandise
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary hover:bg-muted/50 transition py-2 px-2 rounded" onClick={() => setIsOpen(false)}>
                About
              </Link>
              <Link href="/cart" className="text-foreground hover:text-primary hover:bg-muted/50 transition py-2 px-2 rounded flex items-center gap-2" onClick={() => setIsOpen(false)}>
                <span>🛒</span> Cart
              </Link>
            </nav>
          )}
        </div>
      </header>
    </>
  )
}

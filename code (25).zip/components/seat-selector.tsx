"use client"

import { useState, useCallback } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronDown } from "lucide-react"

interface SeatSelectorProps {
  eventId: number
  eventTitle: string
  venue: string
  date: string
  time: string
  ticketTypes: Array<{ type: string; price: number; available: boolean }>
  onSelectTicket: (ticketType: string, quantity: number) => void
}

export default function SeatSelector({
  eventId,
  eventTitle,
  venue,
  date,
  time,
  ticketTypes,
  onSelectTicket,
}: SeatSelectorProps) {
  const [selectedTicketType, setSelectedTicketType] = useState<string>(ticketTypes[0]?.type || "")
  const [quantity, setQuantity] = useState(1)
  const [isOpen, setIsOpen] = useState(false)

  const handleAddToCart = useCallback(() => {
    if (selectedTicketType) {
      onSelectTicket(selectedTicketType, quantity)
      setQuantity(1)
    }
  }, [selectedTicketType, quantity, onSelectTicket])

  const selectedPrice = ticketTypes.find((t) => t.type === selectedTicketType)?.price || 0

  return (
    <Card className="p-6 border-border">
      <div className="space-y-6">
        {/* Event Info */}
        <div>
          <h3 className="text-sm text-muted-foreground mb-1">Event</h3>
          <p className="text-lg font-bold text-foreground">{eventTitle}</p>
          <p className="text-sm text-muted-foreground">{venue}</p>
          <p className="text-sm text-muted-foreground">
            {date} at {time}
          </p>
        </div>

        {/* Ticket Type Selection */}
        <div>
          <label className="text-sm font-semibold text-foreground mb-2 block">Ticket Type</label>
          <div className="relative">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="w-full p-3 border border-border rounded-lg bg-background text-foreground flex items-center justify-between hover:border-accent transition"
            >
              <span>{selectedTicketType}</span>
              <ChevronDown className={`w-4 h-4 transition ${isOpen ? "rotate-180" : ""}`} />
            </button>
            {isOpen && (
              <div className="absolute top-full left-0 right-0 mt-2 border border-border rounded-lg bg-background z-50 shadow-lg">
                {ticketTypes.map((ticket) => (
                  <button
                    key={ticket.type}
                    onClick={() => {
                      setSelectedTicketType(ticket.type)
                      setIsOpen(false)
                    }}
                    disabled={!ticket.available}
                    className="w-full p-3 text-left hover:bg-accent/10 disabled:opacity-50 disabled:cursor-not-allowed transition border-b border-border last:border-b-0 flex justify-between items-center"
                  >
                    <span className="text-foreground">{ticket.type}</span>
                    <span className="text-accent font-semibold">${ticket.price}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Quantity Selection */}
        <div>
          <label className="text-sm font-semibold text-foreground mb-2 block">Quantity</label>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              className="w-10 h-10 border border-border rounded-lg hover:bg-accent/10 transition"
            >
              −
            </button>
            <input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(Math.max(1, Number.parseInt(e.target.value) || 1))}
              className="flex-1 p-2 border border-border rounded-lg text-center bg-background text-foreground"
              min="1"
              max="10"
            />
            <button
              onClick={() => setQuantity(Math.min(10, quantity + 1))}
              className="w-10 h-10 border border-border rounded-lg hover:bg-accent/10 transition"
            >
              +
            </button>
          </div>
        </div>

        {/* Price Summary */}
        <div className="bg-accent/5 p-4 rounded-lg border border-accent/20">
          <div className="flex justify-between mb-2">
            <span className="text-muted-foreground">Price per ticket</span>
            <span className="text-foreground font-semibold">${selectedPrice}</span>
          </div>
          <div className="flex justify-between text-lg font-bold text-accent pt-2 border-t border-accent/20">
            <span>Total</span>
            <span>${(selectedPrice * quantity).toFixed(2)}</span>
          </div>
        </div>

        {/* Add to Cart Button */}
        <Button
          onClick={handleAddToCart}
          className="w-full bg-accent text-accent-foreground hover:bg-accent/90 py-6 text-lg font-semibold"
        >
          Add {quantity} to Cart
        </Button>
      </div>
    </Card>
  )
}

"use client"

import { useEffect, useState } from "react"

export default function HeroCarousel() {
  const [currentImage, setCurrentImage] = useState(0)

  const images = [
    "/morgan-wallen-concert-stage-lights.jpg",
    "/country-music-stadium-concert.jpg",
    "/live-concert-performance-crowd.jpg",
    "/music-festival-outdoor-stage.jpg",
    "/country-artist-stadium-tour.jpg",
    "/concert-pyrotechnics-effects.jpg",
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % images.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [images.length])

  return (
    <div className="absolute inset-0 overflow-hidden">
      <div className="relative w-full h-full">
        {images.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
              index === currentImage ? "opacity-100" : "opacity-0"
            }`}
          >
            <img
              src={image || "/placeholder.svg"}
              alt={`Morgan Wallen concert ${index + 1}`}
              className="w-full h-full object-cover"
              loading={index === currentImage ? "eager" : "lazy"}
            />
          </div>
        ))}
      </div>
    </div>
  )
}

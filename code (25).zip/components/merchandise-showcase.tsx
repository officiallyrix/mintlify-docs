"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowRight, Sparkles } from 'lucide-react'

export default function MerchandiseShowcase() {
  return (
    <section className="py-20 bg-gradient-to-b from-accent/5 to-transparent border-t border-border">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left: Featured Product Images */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <Card className="overflow-hidden h-64 bg-muted relative">
                <img
                  src="/morgan-wallen-tour-shirt.jpg"
                  alt="Tour T-Shirt"
                  className="w-full h-full object-cover hover:scale-105 transition-transform"
                />
              </Card>
              <Card className="overflow-hidden h-48 bg-muted relative">
                <img
                  src="/baseball-cap-logo.jpg"
                  alt="Classic Logo Cap"
                  className="w-full h-full object-cover hover:scale-105 transition-transform"
                />
              </Card>
            </div>
            <div className="space-y-4 mt-8">
              <Card className="overflow-hidden h-48 bg-muted relative">
                <img
                  src="/black-hoodie-tour.jpg"
                  alt="Tour Hoodie"
                  className="w-full h-full object-cover hover:scale-105 transition-transform"
                />
              </Card>
              <Card className="overflow-hidden h-64 bg-muted relative">
                <img
                  src="/tour-merchandise-tee.jpg"
                  alt="World Tour Tee"
                  className="w-full h-full object-cover hover:scale-105 transition-transform"
                />
              </Card>
            </div>
          </div>

          {/* Right: Content */}
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-accent" />
              <span className="text-sm font-bold uppercase text-accent">Official Tour Merch</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-foreground text-balance">
              Exclusive Merchandise Collection
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Get official Morgan Wallen tour merchandise including limited-edition t-shirts, hoodies, hats, and
              accessories. Show your support and represent the tour in style. All items are officially licensed and
              available exclusively through our store.
            </p>

            <div className="space-y-4 pt-4">
              <div className="flex items-start gap-3">
                <span className="text-accent font-bold text-lg">✓</span>
                <div>
                  <p className="font-semibold text-foreground">Premium Quality</p>
                  <p className="text-sm text-muted-foreground">High-quality apparel and accessories</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-accent font-bold text-lg">✓</span>
                <div>
                  <p className="font-semibold text-foreground">Limited Edition</p>
                  <p className="text-sm text-muted-foreground">Exclusive designs that sell out fast</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-accent font-bold text-lg">✓</span>
                <div>
                  <p className="font-semibold text-foreground">Fast Shipping</p>
                  <p className="text-sm text-muted-foreground">Quick delivery to your door</p>
                </div>
              </div>
            </div>

            <Link href="/merchandise">
              <Button className="bg-accent text-accent-foreground hover:bg-accent/90 gap-2 py-6 text-base">
                Shop All Merchandise
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

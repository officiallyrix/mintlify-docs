"use client"

import Link from "next/link"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { events, footballMatches, allEvents } from "@/lib/events-data"

interface EventGridProps {
  eventType?: "all" | "concerts" | "football"
}

export default function EventGrid({ eventType = "all" }: EventGridProps) {
  let displayEvents = events

  if (eventType === "concerts") {
    displayEvents = events
  } else if (eventType === "football") {
    displayEvents = footballMatches
  } else if (eventType === "all") {
    displayEvents = allEvents
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {displayEvents.map((event: any) => (
        <Link key={event.id} href={`/event/${event.id}`}>
          <Card className="overflow-hidden transition-all duration-300 cursor-pointer h-full flex flex-col hover:border-primary/80 group border-primary/20 neon-card-hover bg-card">
            {/* Event Image */}
            <div className="relative w-full h-48 overflow-hidden bg-muted">
              <img
                src={event.image || "/placeholder.svg"}
                alt={event.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              {!event.available && (
                <div className="absolute inset-0 bg-black/60 flex items-center justify-center backdrop-blur-sm">
                  <span className="text-white font-bold text-lg">Sold Out</span>
                </div>
              )}
              <div className="absolute top-3 right-3 bg-accent text-accent-foreground px-3 py-1 rounded-full text-xs font-bold neon-badge">
                {event.available ? "Available" : "Sold Out"}
              </div>
              {event.sport && (
                <div className="absolute top-3 left-3 bg-primary text-primary-foreground px-3 py-1 rounded-full text-xs font-bold">
                  {event.sport}
                </div>
              )}
            </div>

            {/* Event Details */}
            <div className="p-5 flex-1 flex flex-col">
              <h3 className="text-lg font-bold text-foreground mb-1">{event.title}</h3>
              <p className="text-accent text-sm font-semibold mb-4">
                {event.artist || event.sport || "Event"}
              </p>

              {/* Info Grid */}
              <div className="space-y-3 mb-4 flex-1">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>📅</span>
                  <span>{new Date(event.date).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>📍</span>
                  <span>{event.location}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>👥</span>
                  <span>{event.seats_available} seats available</span>
                </div>
              </div>

              {/* Rating */}
              <div className="flex items-center gap-2 mb-4 text-sm">
                <div className="flex items-center">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <span key={i} className={i < Math.floor(event.rating) ? "text-primary" : "text-muted"}>
                      ★
                    </span>
                  ))}
                </div>
                <span className="text-muted-foreground text-xs">({event.reviews})</span>
              </div>

              {/* Footer with Price and Button */}
              <div className="flex items-center justify-between pt-4 border-t border-primary/20">
                <div className="flex flex-col">
                  <span className="text-xs text-muted-foreground">From</span>
                  <span className="text-2xl font-bold text-foreground">${event.price}</span>
                </div>
                <Button
                  size="sm"
                  disabled={!event.available}
                  className="relative transition-all duration-300 bg-accent text-accent-foreground neon-shadow-accent-button hover:shadow-lg"
                >
                  {event.available ? "Get Tickets" : "Sold Out"}
                </Button>
              </div>
            </div>
          </Card>
        </Link>
      ))}
    </div>
  )
}

"use client"

import { Button } from "@/components/ui/button"
import CountdownTimer from "./countdown-timer"
import HeroCarousel from "./hero-carousel"
import Link from "next/link"

export default function Hero() {
  return (
    <section className="relative w-full overflow-hidden min-h-[70vh] sm:min-h-[75vh] md:min-h-[80vh] flex items-center bg-background">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <HeroCarousel />
        {/* Overlays for text readability */}
        <div className="absolute inset-0 bg-gradient-to-r from-background/60 via-background/40 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background/50"></div>
      </div>

      {/* Content - Higher z-index to ensure visibility */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-12 sm:py-16 md:py-20 lg:py-32 z-10 w-full">
        <div className="max-w-3xl">
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-foreground mb-4 sm:mb-6 text-balance leading-tight animate-fade-in-up">
            Morgan Wallen
            <br />
            <span className="text-accent">Live Tour 2026</span>
          </h1>

          <p className="text-base sm:text-lg md:text-xl text-foreground/90 mb-6 sm:mb-8 max-w-2xl text-balance leading-relaxed animate-fade-in-up">
            Experience one of the most anticipated country music tours of the year. Premium venues, unforgettable
            performances, and passionate fans from across the nation.
          </p>

          <div className="mb-8 sm:mb-10 p-4 sm:p-6 bg-card/90 backdrop-blur-sm rounded-lg border border-border animate-fade-in-up">
            <p className="text-xs sm:text-sm font-semibold text-muted-foreground mb-3 sm:mb-4">Next Performance In</p>
            <CountdownTimer targetDate="2026-04-10T19:00:00" />
          </div>

          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 mb-8 sm:mb-12 animate-fade-in-up">
            <Link href="/#events" className="w-full sm:w-auto">
              <Button size="lg" className="btn-primary w-full">
                Browse Events
              </Button>
            </Link>
            <Link href="/about" className="w-full sm:w-auto">
              <Button size="lg" variant="outline" className="btn-secondary w-full">
                Tour Information
              </Button>
            </Link>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-3 sm:gap-6 animate-fade-in-up">
            <div className="flex flex-col">
              <span className="text-2xl sm:text-3xl md:text-4xl font-bold text-accent">50+</span>
              <span className="text-xs sm:text-sm text-foreground/80">Tour Dates</span>
            </div>
            <div className="flex flex-col">
              <span className="text-2xl sm:text-3xl md:text-4xl font-bold text-accent">1M+</span>
              <span className="text-xs sm:text-sm text-foreground/80">Fans Expected</span>
            </div>
            <div className="flex flex-col">
              <span className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-accent leading-tight">Nationwide</span>
              <span className="text-xs sm:text-sm text-foreground/80">Coverage</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

"use client"

import { useState } from "react"
import Image from "next/image"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Heart } from "lucide-react"
import type { MerchandiseProduct } from "@/lib/merchandise"

interface MerchandiseCardProps {
  product: MerchandiseProduct
  onAddToCart: (product: MerchandiseProduct, selectedColor: string, selectedSize: string) => void
}

export function MerchandiseCard({ product, onAddToCart }: MerchandiseCardProps) {
  const [selectedColor, setSelectedColor] = useState(product.colors[0])
  const [selectedSize, setSelectedSize] = useState(product.sizes[0])
  const [isWishlisted, setIsWishlisted] = useState(false)

  return (
    <Card className="group overflow-hidden border-border hover:shadow-lg transition-shadow duration-300">
      {/* Product Image */}
      <div className="relative h-80 bg-muted overflow-hidden">
        <Image
          src={product.image || "/placeholder.svg"}
          alt={product.name}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <button
          onClick={() => setIsWishlisted(!isWishlisted)}
          className="absolute top-4 right-4 z-10 bg-background/90 backdrop-blur p-2 rounded-full hover:bg-accent/20 transition"
        >
          <Heart className={`w-5 h-5 ${isWishlisted ? "fill-accent text-accent" : "text-muted-foreground"}`} />
        </button>
        {product.featured && (
          <div className="absolute top-4 left-4 bg-accent text-accent-foreground px-3 py-1 rounded-full text-xs font-bold">
            FEATURED
          </div>
        )}
      </div>

      {/* Product Info */}
      <div className="p-6">
        <p className="text-xs text-muted-foreground font-semibold uppercase mb-2">{product.category}</p>
        <h3 className="text-lg font-bold text-foreground mb-1 line-clamp-2">{product.name}</h3>
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{product.description}</p>

        {/* Color Selection */}
        <div className="mb-4">
          <label className="text-xs font-semibold text-muted-foreground mb-2 block">COLOR</label>
          <div className="flex gap-2">
            {product.colors.map((color) => (
              <button
                key={color}
                onClick={() => setSelectedColor(color)}
                className={`w-6 h-6 rounded-full border-2 transition ${
                  selectedColor === color ? "border-accent" : "border-muted hover:border-muted-foreground"
                }`}
                title={color}
                style={{
                  backgroundColor:
                    color === "Black"
                      ? "#000"
                      : color === "White"
                        ? "#fff"
                        : color === "Navy"
                          ? "#001f3f"
                          : color === "Charcoal"
                            ? "#36454f"
                            : color === "Dark Gray"
                              ? "#555"
                              : color === "Gray"
                                ? "#888"
                                : color === "Tan"
                                  ? "#d2b48c"
                                  : color === "Natural"
                                    ? "#f5e6d3"
                                    : "#ccc",
                }}
              />
            ))}
          </div>
        </div>

        {/* Size Selection */}
        <div className="mb-4">
          <label className="text-xs font-semibold text-muted-foreground mb-2 block">SIZE</label>
          <div className="flex flex-wrap gap-2">
            {product.sizes.map((size) => (
              <button
                key={size}
                onClick={() => setSelectedSize(size)}
                className={`px-3 py-1 rounded border text-sm font-semibold transition ${
                  selectedSize === size
                    ? "bg-accent text-accent-foreground border-accent"
                    : "border-muted hover:border-accent"
                }`}
              >
                {size}
              </button>
            ))}
          </div>
        </div>

        {/* Price and Button */}
        <div className="flex items-center justify-between pt-4 border-t border-border">
          <p className="text-2xl font-bold text-accent">${product.price.toFixed(2)}</p>
          <Button
            onClick={() => onAddToCart(product, selectedColor, selectedSize)}
            disabled={!product.inStock}
            className="bg-accent text-accent-foreground hover:bg-accent/90 gap-2"
            size="sm"
          >
            <ShoppingCart className="w-4 h-4" />
            {product.inStock ? "Add" : "Out of Stock"}
          </Button>
        </div>
      </div>
    </Card>
  )
}

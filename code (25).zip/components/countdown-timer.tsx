"use client"

import { useEffect, useState } from "react"

interface TimeLeft {
  days: number
  hours: number
  minutes: number
  seconds: number
}

export default function CountdownTimer({ targetDate }: { targetDate: string }) {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  })

  useEffect(() => {
    const updateCountdown = () => {
      const target = new Date(targetDate).getTime()
      const now = new Date().getTime()
      const difference = target - now

      if (difference > 0) {
        const newTimeLeft = {
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        }
        setTimeLeft(newTimeLeft)
      }
    }

    updateCountdown()
    const interval = setInterval(updateCountdown, 1000)
    return () => clearInterval(interval)
  }, [targetDate])

  return (
    <div className="w-full">
      <div className="grid grid-cols-4 gap-2 sm:gap-4 md:gap-6">
        <div className="flex flex-col items-center justify-center">
          <div className="bg-gradient-to-br from-accent to-accent/90 text-accent-foreground rounded-lg px-3 py-3 sm:px-4 sm:py-4 md:px-6 md:py-6 text-2xl sm:text-3xl md:text-5xl font-bold w-full text-center shadow-lg">
            {String(timeLeft.days).padStart(2, "0")}
          </div>
          <span className="text-xs sm:text-sm md:text-base font-semibold text-foreground mt-2 sm:mt-3 tracking-wide">DAYS</span>
        </div>

        <div className="flex flex-col items-center justify-center">
          <div className="bg-gradient-to-br from-accent to-accent/90 text-accent-foreground rounded-lg px-3 py-3 sm:px-4 sm:py-4 md:px-6 md:py-6 text-2xl sm:text-3xl md:text-5xl font-bold w-full text-center shadow-lg">
            {String(timeLeft.hours).padStart(2, "0")}
          </div>
          <span className="text-xs sm:text-sm md:text-base font-semibold text-foreground mt-2 sm:mt-3 tracking-wide">HRS</span>
        </div>

        <div className="flex flex-col items-center justify-center">
          <div className="bg-gradient-to-br from-accent to-accent/90 text-accent-foreground rounded-lg px-3 py-3 sm:px-4 sm:py-4 md:px-6 md:py-6 text-2xl sm:text-3xl md:text-5xl font-bold w-full text-center shadow-lg">
            {String(timeLeft.minutes).padStart(2, "0")}
          </div>
          <span className="text-xs sm:text-sm md:text-base font-semibold text-foreground mt-2 sm:mt-3 tracking-wide">MIN</span>
        </div>

        <div className="flex flex-col items-center justify-center">
          <div className="bg-gradient-to-br from-accent to-accent/90 text-accent-foreground rounded-lg px-3 py-3 sm:px-4 sm:py-4 md:px-6 md:py-6 text-2xl sm:text-3xl md:text-5xl font-bold w-full text-center shadow-lg">
            {String(timeLeft.seconds).padStart(2, "0")}
          </div>
          <span className="text-xs sm:text-sm md:text-base font-semibold text-foreground mt-2 sm:mt-3 tracking-wide">SEC</span>
        </div>
      </div>
    </div>
  )
}

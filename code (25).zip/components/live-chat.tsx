"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { MessageCircle, X, Send, Loader } from 'lucide-react'
import { sendChatMessage } from "@/lib/chat-service"

interface Message {
  id: string
  text: string
  sender: "user" | "support"
  timestamp: Date
  isLoading?: boolean
}

export default function LiveChat() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Welcome to Morgan Wallen Live Support! 🎤 Ask me anything about tickets, events, orders, or general questions. How can I help?",
      sender: "support",
      timestamp: new Date(),
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsLoading(true)

    try {
      const reply = await sendChatMessage(inputValue)

      const supportMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: reply,
        sender: "support",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, supportMessage])
    } catch (error) {
      console.error("[v0] Error sending message:", error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: "Sorry, I'm having trouble responding right now. Please try again or contact support@morganwallenlive.com",
        sender: "support",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleGoogleMessages = () => {
    window.open("https://messages.google.com/business", "_blank")
  }

  return (
    <>
      {/* Chat Widget Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40 p-3 sm:p-4 bg-primary text-primary-foreground rounded-full shadow-lg hover:shadow-xl hover:scale-110 transition-all"
        aria-label="Open chat"
      >
        {isOpen ? <X size={20} className="sm:w-6 sm:h-6" /> : <MessageCircle size={20} className="sm:w-6 sm:h-6" />}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <Card className="fixed bottom-16 right-4 sm:bottom-24 sm:right-6 w-[calc(100vw-2rem)] sm:w-96 max-w-sm shadow-2xl z-40 flex flex-col h-[500px] max-h-[calc(100vh-8rem)]">
          {/* Header */}
          <div className="bg-primary text-primary-foreground p-3 sm:p-4 rounded-t-lg">
            <h3 className="font-bold text-sm sm:text-base">Morgan Wallen Live Support</h3>
            <p className="text-xs sm:text-sm opacity-90">AI-powered • Always here to help</p>
          </div>

          {/* Messages Container */}
          <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3 sm:space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[85%] sm:max-w-xs px-3 sm:px-4 py-2 rounded-lg ${
                    message.sender === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"
                  }`}
                >
                  {message.isLoading ? (
                    <div className="flex items-center gap-2">
                      <Loader size={14} className="animate-spin" />
                      <span className="text-xs sm:text-sm">Thinking...</span>
                    </div>
                  ) : (
                    <>
                      <p className="text-xs sm:text-sm leading-relaxed">{message.text}</p>
                      <span className="text-[10px] sm:text-xs opacity-70 block mt-1">
                        {message.timestamp.toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>
                    </>
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-muted text-foreground px-3 sm:px-4 py-2 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Loader size={14} className="animate-spin" />
                    <span className="text-xs sm:text-sm">Typing...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Actions */}
          <div className="px-3 sm:px-4 py-2 space-y-2 border-t border-border">
            <Button
              variant="outline"
              size="sm"
              className="w-full text-[10px] sm:text-xs bg-transparent h-8"
              onClick={handleGoogleMessages}
            >
              📱 Message via Google Messages
            </Button>
            <a href="mailto:support@morganwallenlive.com" className="block">
              <Button variant="outline" size="sm" className="w-full text-[10px] sm:text-xs bg-transparent h-8">
                ✉️ Email Support
              </Button>
            </a>
          </div>

          {/* Input */}
          <div className="border-t border-border p-3 sm:p-4 rounded-b-lg flex gap-2">
            <Input
              placeholder="Ask about tickets..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === "Enter" && !isLoading) {
                  handleSendMessage()
                }
              }}
              disabled={isLoading}
              className="flex-1 text-sm"
            />
            <Button onClick={handleSendMessage} size="sm" className="px-2 sm:px-3" disabled={isLoading}>
              <Send size={14} className="sm:w-4 sm:h-4" />
            </Button>
          </div>
        </Card>
      )}
    </>
  )
}

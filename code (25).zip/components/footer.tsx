"use client"

import Link from "next/link"
import Image from "next/image"

export default function Footer() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 mb-6 sm:mb-8">
          {/* Brand Section */}
          <div className="sm:col-span-2 md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-3 sm:mb-4 hover:opacity-80 transition">
              <Image
                src="/mw-logo.jpg"
                alt="Morgan Wallen Logo"
                width={40}
                height={40}
                className="h-8 sm:h-10 w-auto rounded-full"
              />
              <span className="font-bold text-foreground text-sm sm:text-base">Morgan Wallen Live</span>
            </Link>
            <p className="text-muted-foreground text-xs sm:text-sm leading-relaxed">
              Official tour ticketing and event information for Morgan Wallen 2026.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-foreground mb-3 sm:mb-4 text-sm sm:text-base">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/events" className="text-muted-foreground hover:text-accent transition text-xs sm:text-sm">
                  Events
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-accent transition text-xs sm:text-sm">
                  About
                </Link>
              </li>
              <li>
                <Link href="/admin" className="text-muted-foreground hover:text-accent transition text-xs sm:text-sm">
                  Admin
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-bold text-foreground mb-3 sm:mb-4 text-sm sm:text-base">Support</h4>
            <ul className="space-y-2">
              <li className="flex items-start gap-2 text-muted-foreground">
                <span className="flex-shrink-0 text-sm">✉️</span>
                <a href="mailto:support@morganwallenlive.com" className="hover:text-accent transition break-all text-xs sm:text-sm">
                  support@morganwallenlive.com
                </a>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground">
                <span className="flex-shrink-0 text-sm">📱</span>
                <a href="tel:+1234567890" className="hover:text-accent transition text-xs sm:text-sm">
                  (123) 456-7890
                </a>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground">
                <span className="flex-shrink-0 text-sm">📍</span>
                <span className="text-xs sm:text-sm">Nashville, TN</span>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-bold text-foreground mb-3 sm:mb-4 text-sm sm:text-base">Legal</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/privacy" className="text-muted-foreground hover:text-accent transition text-xs sm:text-sm">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-muted-foreground hover:text-accent transition text-xs sm:text-sm">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border pt-6 sm:pt-8 text-center text-muted-foreground text-xs sm:text-sm">
          <p>© 2026 Morgan Wallen Live. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

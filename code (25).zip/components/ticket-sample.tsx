"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useState } from "react"

interface TicketSampleProps {
  eventId: number
  eventTitle: string
  venue: string
  date: string
  time: string
  ticketType: "General Admission" | "VIP" | "Premium VIP"
  price: number
  ticketNumber: string
  holderName: string
}

export default function TicketSample({
  eventId,
  eventTitle,
  venue,
  date,
  time,
  ticketType,
  price,
  ticketNumber,
  holderName,
}: TicketSampleProps) {
  const [isFlipped, setIsFlipped] = useState(false)

  const ticketColors = {
    "General Admission": { stripe: "bg-blue-600", accent: "text-blue-400" },
    VIP: { stripe: "bg-purple-600", accent: "text-purple-400" },
    "Premium VIP": { stripe: "bg-amber-600", accent: "text-amber-400" },
  }

  const colors = ticketColors[ticketType]

  return (
    <div className="perspective w-full max-w-3xl">
      <div
        className={`relative w-full transition-transform duration-500 ${isFlipped ? "transform scale-100" : ""}`}
        style={{
          transformStyle: "preserve-3d",
          transform: isFlipped ? "rotateY(180deg)" : "rotateY(0deg)",
        }}
      >
        {/* Front of Ticket */}
        <div
          style={{
            backfaceVisibility: "hidden",
          }}
        >
          <Card className="overflow-hidden w-full border-2 border-yellow-600/40">
            <div
              className="relative bg-cover bg-center"
              style={{
                backgroundImage: "url('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/MorganWallen%20ticket-BTosSO8PFBY9Vd3gWNQzlY767mFz5r.jpg')",
                backgroundSize: "cover",
                backgroundPosition: "center",
                minHeight: "400px",
              }}
            >
              {/* Semi-transparent overlay for readability */}
              <div className="absolute inset-0 bg-black/50"></div>

              <div className="relative p-12 text-white h-full flex flex-col justify-between">
                {/* Header with Artist Image */}
                <div className="flex justify-between items-start mb-12">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-yellow-500 shadow-lg">
                      <img 
                        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Morgan-Wallen-Still-The-Problem-Tour-2026-T-Shirt-768x768-XmhIoSodBRDSWh3qC7rSLsWp4ri1Pf.jpg" 
                        alt="Morgan Wallen" 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <h3 className="text-3xl font-black tracking-widest">MORGAN WALLEN</h3>
                      <p className="text-xs opacity-75 mt-2 tracking-wide">STILL THE PROBLEM TOUR 2026</p>
                    </div>
                  </div>
                  <div
                    className={`${colors.stripe} text-white px-6 py-2 rounded-full text-sm font-black tracking-wider shadow-lg`}
                  >
                    {ticketType}
                  </div>
                </div>

                {/* Main Event Info */}
                <div className="grid grid-cols-2 gap-8 mb-12 pb-8 border-b-2 border-white/30">
                  <div>
                    <p className="text-xs opacity-70 font-semibold tracking-widest mb-2 uppercase">Event</p>
                    <p className="font-bold text-lg leading-tight">{eventTitle}</p>
                  </div>
                  <div>
                    <p className="text-xs opacity-70 font-semibold tracking-widest mb-2 uppercase">Venue</p>
                    <p className="font-bold text-lg leading-tight">{venue}</p>
                  </div>
                  <div>
                    <p className="text-xs opacity-70 font-semibold tracking-widest mb-2 uppercase">Date</p>
                    <p className="font-bold text-lg leading-tight">{date}</p>
                  </div>
                  <div>
                    <p className="text-xs opacity-70 font-semibold tracking-widest mb-2 uppercase">Time</p>
                    <p className="font-bold text-lg leading-tight">{time}</p>
                  </div>
                </div>

                {/* Ticket Details */}
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <p className="text-xs opacity-70 font-semibold tracking-widest mb-2">TICKET #</p>
                    <p className="font-mono font-bold text-sm text-yellow-200">{ticketNumber}</p>
                  </div>
                  <div>
                    <p className="text-xs opacity-70 font-semibold tracking-widest mb-2">PRICE</p>
                    <p className={`font-bold text-lg ${colors.accent}`}>${price}</p>
                  </div>
                </div>

                {/* Holder Name */}
                <div className="border-t-2 border-white/30 pt-6">
                  <p className="text-xs opacity-70 font-semibold tracking-widest uppercase mb-3">Admit One</p>
                  <p className="font-bold text-2xl tracking-wide">{holderName}</p>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Back of Ticket */}
        <div
          style={{
            backfaceVisibility: "hidden",
            transform: "rotateY(180deg)",
          }}
        >
          <Card className="overflow-hidden w-full bg-gradient-to-br from-slate-900 to-slate-800 border-2 border-yellow-600/40">
            <div className="p-12 text-white h-full flex flex-col justify-between" style={{ minHeight: "400px" }}>
              <div>
                <h3 className="text-lg font-black mb-6 tracking-wide">TERMS & CONDITIONS</h3>
                <div className="space-y-3 text-xs opacity-80 leading-relaxed">
                  <p>• This ticket is valid only for the event date and time specified</p>
                  <p>• Non-transferable and non-refundable</p>
                  <p>• Must present valid ID at entry</p>
                  <p>• No re-entry permitted after departure</p>
                  <p>• Venue rules and regulations apply</p>
                  <p>• Lost or stolen tickets cannot be replaced</p>
                </div>
              </div>

              <div className="border-t-2 border-white/20 pt-6">
                <p className="text-xs opacity-70 mb-2">Event Organizer</p>
                <p className="font-bold">Morgan Wallen Official</p>
                <p className="text-xs opacity-70 mt-2">morganwallenlive.com</p>
              </div>
            </div>

            {/* Decorative Stripes */}
            <div className={`${colors.stripe} h-3`}></div>
          </Card>
        </div>
      </div>

      <div className="text-center mt-6">
        <Button onClick={() => setIsFlipped(!isFlipped)} className={`${colors.stripe} text-white hover:opacity-90`}>
          {isFlipped ? "View Front" : "View Back"}
        </Button>
      </div>
    </div>
  )
}

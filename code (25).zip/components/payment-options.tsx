"use client"

import { useState } from "react"
import Image from "next/image"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function PaymentOptions() {
  const [copiedWallet, setCopiedWallet] = useState(false)

  const bitcoinWallet = "bc1q2lznq5f6uaglgfyump4ad2g9lfuyks0vwexyj2"
  const flutterWaveLink = "https://sandbox.flutterwave.com/pay/qrslug-118314-m6bypz7tchhb"
  const trustWalletLink =
    "https://link.trustwallet.com/send?asset=c0&address=bc1q2lznq5f6uaglgfyump4ad2g9lfuyks0vwexyj2"

  const copyWalletAddress = () => {
    navigator.clipboard.writeText(bitcoinWallet)
    setCopiedWallet(true)
    setTimeout(() => setCopiedWallet(false), 2000)
  }

  return (
    <section className="py-12 sm:py-16 px-4 sm:px-6 bg-gradient-to-b from-background to-card/30">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8 sm:mb-12 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-2 sm:mb-3 text-balance neon-text">Payment Options</h2>
          <p className="text-muted-foreground text-base sm:text-lg max-w-2xl mx-auto">
            Choose your preferred payment method to complete your purchase securely
          </p>
        </div>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
          {/* Flutterwave QR Code */}
          <Card className="card-classic border-accent/20 hover:border-accent/50 flex flex-col">
            <CardHeader>
              <CardTitle className="text-accent text-lg sm:text-xl">Flutterwave QR</CardTitle>
              <CardDescription className="text-sm">Scan to pay with Flutterwave</CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col items-center justify-center gap-4">
              <div className="bg-white p-4 sm:p-6 rounded-lg shadow-lg border-2 border-accent/30 w-full flex justify-center">
                <Image
                  src="/images/qrslug-118314-m6bypz7tchhb.png"
                  alt="Flutterwave Payment QR Code - Scan to pay"
                  width={240}
                  height={240}
                  priority
                  className="w-48 h-48 sm:w-56 sm:h-56 object-contain"
                />
              </div>
            </CardContent>
          </Card>

          {/* Bitcoin Wallet */}
          <Card className="card-classic border-chart-1/20 hover:border-chart-1/50 flex flex-col">
            <CardHeader>
              <CardTitle className="text-chart-1 text-lg sm:text-xl">Bitcoin Wallet</CardTitle>
              <CardDescription className="text-sm">Send Bitcoin directly</CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col items-center justify-between gap-4">
              <div className="bg-card border-2 border-chart-1/30 rounded-lg p-3 sm:p-4 w-full text-center">
                <p className="text-xs text-muted-foreground mb-2 font-semibold">Wallet Address</p>
                <p className="text-xs text-foreground font-mono break-all leading-relaxed">{bitcoinWallet}</p>
              </div>
              <div className="flex gap-2 w-full">
                <Button
                  onClick={copyWalletAddress}
                  variant="outline"
                  className="flex-1 bg-chart-1/10 border-chart-1/30 text-foreground hover:bg-chart-1/20 hover:text-chart-1 text-sm"
                >
                  {copiedWallet ? "✓ Copied!" : "Copy Address"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Trust Wallet */}
          <Card className="card-classic border-chart-2/20 hover:border-chart-2/50 flex flex-col sm:col-span-2 md:col-span-1">
            <CardHeader>
              <CardTitle className="text-chart-2 text-lg sm:text-xl">Trust Wallet</CardTitle>
              <CardDescription className="text-sm">Send crypto via Trust Wallet</CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col items-center justify-between gap-4">
              <div className="bg-card border-2 border-chart-2/30 rounded-lg p-3 sm:p-4 text-center w-full">
                <p className="text-sm text-muted-foreground mb-3">One-click payment with Trust Wallet</p>
                <svg className="w-12 h-12 sm:w-16 sm:h-16 mx-auto text-chart-2 opacity-80" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                </svg>
              </div>
              <Button asChild className="w-full bg-chart-2 text-background hover:bg-chart-2/80 text-sm">
                <a href={trustWalletLink} target="_blank" rel="noopener noreferrer">
                  Open Trust Wallet
                </a>
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="mt-6 sm:mt-8 p-4 sm:p-6 bg-card border-2 border-accent/20 rounded-lg">
          <p className="text-xs sm:text-sm text-muted-foreground text-center leading-relaxed">
            ✓ All payments are secure and processed through trusted payment providers. Your transaction information is
            encrypted and protected.
          </p>
        </div>
      </div>
    </section>
  )
}

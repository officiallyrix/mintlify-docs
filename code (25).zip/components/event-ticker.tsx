"use client"

import { useEffect, useState } from "react"
import { events } from "@/lib/events-data"

export default function EventTicker() {
  const [displayEvents, setDisplayEvents] = useState<typeof events>([])

  useEffect(() => {
    // Display first 5 events in rotating ticker
    setDisplayEvents(events.slice(0, 5))
  }, [])

  return (
    <div className="w-full bg-gradient-to-r from-primary/10 to-secondary/10 border-y border-border">
      <div className="max-w-7xl mx-auto px-4">
        {/* Ticker Title */}
        <div className="py-3 border-b border-border/50">
          <p className="text-xs font-bold text-accent uppercase tracking-widest">Live Event Ticker</p>
        </div>

        {/* Events Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-0 py-4 divide-x divide-border/30">
          {displayEvents.map((event) => (
            <div key={event.id} className="px-4 py-2">
              <div className="space-y-1">
                <p className="text-xs text-accent font-bold uppercase">{event.location.split(",")[0]}</p>
                <p className="text-sm font-semibold text-foreground line-clamp-1">{event.title}</p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span>📅</span>
                  <span>{new Date(event.date).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span>🕐</span>
                  <span>{event.time}</span>
                </div>
                <div className="pt-2 border-t border-border/30">
                  <p className="text-xs text-muted-foreground">
                    From <span className="text-accent font-bold">${event.price}</span>
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {event.seats_available} <span className="text-accent">seats available</span>
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

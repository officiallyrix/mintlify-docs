"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import Header from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useCart } from "@/components/cart-context"
import { CheckCircle2, ArrowLeft } from "lucide-react"
import { EmbeddedCheckout, EmbeddedCheckoutProvider } from "@stripe/react-stripe-js"
import { loadStripe } from "@stripe/stripe-js"

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)

export default function CheckoutPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { items, clearCart } = useCart()
  const [clientSecret, setClientSecret] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [orderConfirmed, setOrderConfirmed] = useState(false)
  const [sessionId, setSessionId] = useState("")

  useEffect(() => {
    const sessionIdParam = searchParams.get("session_id")
    if (sessionIdParam) {
      setSessionId(sessionIdParam)
      setOrderConfirmed(true)
      setIsLoading(false)
      return
    }

    if (items.length === 0) {
      router.push("/cart")
      return
    }

    const fetchClientSecret = async () => {
      try {
        const response = await fetch("/api/checkout", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ items }),
        })
        const data = await response.json()
        if (data.clientSecret) {
          setClientSecret(data.clientSecret)
        } else {
          throw new Error(data.error)
        }
      } catch (error) {
        console.error("Error fetching client secret:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchClientSecret()
  }, [items, router, searchParams])

  if (isLoading) {
    return (
      <main className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-24 text-center">
          <p className="text-muted-foreground">Loading checkout...</p>
        </div>
      </main>
    )
  }

  if (orderConfirmed) {
    return (
      <main className="min-h-screen bg-background">
        <Header />
        <div className="max-w-2xl mx-auto px-4 py-24 text-center">
          <CheckCircle2 className="w-24 h-24 text-accent mx-auto mb-6" />
          <h1 className="text-4xl font-bold text-foreground mb-2">Order Confirmed!</h1>
          <p className="text-lg text-muted-foreground mb-8">
            Thank you for your purchase. Your tickets have been sent to your email.
          </p>
          <Card className="p-8 bg-accent/10 border-accent/30 mb-8">
            <p className="text-sm text-muted-foreground mb-2">Session ID</p>
            <p className="text-xl font-bold text-accent break-all">{sessionId}</p>
          </Card>
          <div className="space-y-4">
            <Link href="/my-tickets" className="w-full block">
              <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90 py-6 text-lg">
                View My Tickets
              </Button>
            </Link>
            <Link href="/" className="w-full block">
              <Button variant="outline" className="w-full py-6 bg-transparent">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </main>
    )
  }

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const fees = subtotal * 0.1
  const total = subtotal + fees

  return (
    <main className="min-h-screen bg-background">
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-12">
        <Link href="/cart">
          <Button variant="outline" className="mb-6 bg-transparent">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Cart
          </Button>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Stripe Checkout */}
          <div className="lg:col-span-2">
            {clientSecret && (
              <EmbeddedCheckoutProvider stripe={stripePromise} options={{ clientSecret }}>
                <EmbeddedCheckout />
              </EmbeddedCheckoutProvider>
            )}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <Card className="p-6 sticky top-24 border-border">
              <h3 className="text-2xl font-bold text-foreground mb-6">Order Summary</h3>
              <div className="space-y-4 mb-6 max-h-64 overflow-y-auto">
                {items.map((item) => (
                  <div key={item.id} className="pb-4 border-b border-border last:border-b-0">
                    <p className="font-semibold text-foreground">{item.eventTitle}</p>
                    <p className="text-sm text-muted-foreground">{item.ticketType}</p>
                    <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                    <p className="text-sm font-semibold text-accent">${(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                ))}
              </div>
              <div className="space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="text-foreground font-semibold">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Fees</span>
                  <span className="text-foreground font-semibold">${fees.toFixed(2)}</span>
                </div>
                <div className="border-t border-border pt-4 flex justify-between">
                  <span className="text-foreground font-bold">Total</span>
                  <span className="text-foreground font-bold text-lg">${total.toFixed(2)}</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}

"use client"
import Hero from "@/components/hero"
import EventGrid from "@/components/event-grid"
import PaymentOptions from "@/components/payment-options"
import EventTicker from "@/components/event-ticker"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Hero />
      <EventTicker />
      <section id="events" className="px-4 sm:px-6 py-16 sm:py-20 md:py-24 max-w-7xl mx-auto">
        <div className="mb-8 sm:mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-2 text-balance neon-text">Upcoming Events</h2>
          <p className="text-muted-foreground text-base sm:text-lg">Discover and book tickets for amazing live performances</p>
        </div>
        <EventGrid />
      </section>
      <PaymentOptions />
    </main>
  )
}

"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Heart, Share2, MapPin, Calendar, Clock, Star } from "lucide-react"
import { events } from "@/lib/events-data"
import Header from "@/components/header"

export default function EventDetail({ params }: { params: { id: string } }) {
  const eventId = Number.parseInt(params.id)
  const event = events.find((e) => e.id === eventId)
  const [selectedTicket, setSelectedTicket] = useState(event?.ticketTypes[0])
  const [quantity, setQuantity] = useState(1)
  const [isWishlisted, setIsWishlisted] = useState(false)

  if (!event) {
    return (
      <main className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-24 text-center">
          <h1 className="text-4xl font-bold text-foreground mb-4">Event Not Found</h1>
          <Link href="/">
            <Button>Back to Events</Button>
          </Link>
        </div>
      </main>
    )
  }

  const handleAddToCart = () => {
    if (selectedTicket) {
      const cartItem = {
        eventId: event.id,
        title: event.title,
        ticketType: selectedTicket.type,
        price: selectedTicket.price,
        quantity,
      }
      const existingCart = JSON.parse(localStorage.getItem("cart") || "[]")
      existingCart.push(cartItem)
      localStorage.setItem("cart", JSON.stringify(existingCart))
      console.log("Added to cart:", cartItem)
    }
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />

      {/* Hero Image Section */}
      <section className="relative w-full h-96 md:h-screen lg:h-[600px] overflow-hidden">
        <img src={event.image || "/placeholder.svg"} alt={event.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />

        {/* Quick Action Buttons */}
        <div className="absolute top-6 right-6 flex gap-3 z-10">
          <Button
            variant="outline"
            size="icon"
            className="bg-background/80 backdrop-blur"
            onClick={() => setIsWishlisted(!isWishlisted)}
          >
            <Heart className={`w-5 h-5 ${isWishlisted ? "fill-primary text-primary" : ""}`} />
          </Button>
          <Button variant="outline" size="icon" className="bg-background/80 backdrop-blur">
            <Share2 className="w-5 h-5" />
          </Button>
        </div>
      </section>

      {/* Content Section */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Event Header */}
            <div>
              <div className="flex flex-wrap gap-2 mb-4">
                {event.genres.map((genre) => (
                  <span key={genre} className="px-3 py-1 bg-accent/20 text-accent rounded-full text-sm font-medium">
                    {genre}
                  </span>
                ))}
              </div>
              <h1 className="text-5xl font-bold text-foreground mb-2 text-balance">{event.title}</h1>
              <p className="text-2xl text-primary font-semibold mb-4">by {event.artist}</p>

              {/* Rating */}
              <div className="flex items-center gap-2 mb-6">
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${i < Math.floor(event.rating) ? "fill-accent text-accent" : "text-muted"}`}
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">
                  {event.rating} · {event.reviews.toLocaleString()} reviews
                </span>
              </div>
            </div>

            {/* Event Details */}
            <Card className="p-6 space-y-4 border-border">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex gap-3">
                  <Calendar className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-sm text-muted-foreground">Date</p>
                    <p className="text-foreground font-semibold">{event.date}</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Clock className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-sm text-muted-foreground">Time</p>
                    <p className="text-foreground font-semibold">{event.time}</p>
                  </div>
                </div>
                <div className="flex gap-3 md:col-span-2">
                  <MapPin className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-sm text-muted-foreground">Location</p>
                    <p className="text-foreground font-semibold">{event.location}</p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Description */}
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-4">About This Event</h2>
              <p className="text-muted-foreground leading-relaxed text-lg">{event.description}</p>
            </div>

            {/* Capacity Info */}
            <Card className="p-6 bg-primary/10 border-primary/30">
              <p className="text-sm text-muted-foreground mb-2">Availability</p>
              <p className="text-2xl font-bold text-foreground mb-3">
                {event.seats_available} of {event.capacity.toLocaleString()} seats remaining
              </p>
              <div className="w-full bg-border rounded-full h-2">
                <div
                  className="bg-accent h-2 rounded-full"
                  style={{
                    width: `${(event.seats_available / event.capacity) * 100}%`,
                  }}
                />
              </div>
            </Card>
          </div>

          {/* Sidebar - Ticket Selection */}
          <div className="lg:col-span-1">
            <Card className="p-6 sticky top-24 border-border">
              <h3 className="text-2xl font-bold text-foreground mb-6">Select Your Tickets</h3>

              {/* Ticket Type Selection */}
              <div className="space-y-3 mb-6">
                {event.ticketTypes.map((ticket) => (
                  <button
                    key={ticket.type}
                    onClick={() => setSelectedTicket(ticket)}
                    disabled={!ticket.available}
                    className={`w-full p-4 rounded-lg border-2 transition text-left ${
                      selectedTicket?.type === ticket.type
                        ? "border-accent bg-accent/10"
                        : "border-border bg-card hover:border-primary/50"
                    } ${!ticket.available ? "opacity-50 cursor-not-allowed" : ""}`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold text-foreground">{ticket.type}</p>
                        {!ticket.available && <p className="text-xs text-muted-foreground mt-1">Sold Out</p>}
                      </div>
                      <p className="font-bold text-primary">${ticket.price}</p>
                    </div>
                  </button>
                ))}
              </div>

              {/* Quantity Selection */}
              {selectedTicket?.available && (
                <div className="mb-6">
                  <p className="text-sm font-semibold text-foreground mb-3">Quantity</p>
                  <div className="flex items-center gap-3 bg-card border border-border rounded-lg p-1">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-2 hover:bg-primary/20 rounded transition"
                    >
                      −
                    </button>
                    <span className="flex-1 text-center font-semibold text-foreground">{quantity}</span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3 py-2 hover:bg-primary/20 rounded transition"
                    >
                      +
                    </button>
                  </div>
                </div>
              )}

              {/* Price Summary */}
              <Card className="p-4 bg-primary/10 border-primary/30 mb-6">
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="text-foreground font-semibold">
                      ${(selectedTicket ? selectedTicket.price * quantity : 0).toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Fees</span>
                    <span className="text-foreground font-semibold">
                      ${(selectedTicket ? selectedTicket.price * quantity * 0.1 : 0).toFixed(2)}
                    </span>
                  </div>
                  <div className="border-t border-primary/30 pt-2 flex justify-between">
                    <span className="text-foreground font-bold">Total</span>
                    <span className="text-foreground font-bold text-lg">
                      ${(selectedTicket ? selectedTicket.price * quantity * 1.1 : 0).toFixed(2)}
                    </span>
                  </div>
                </div>
              </Card>

              {/* Action Buttons */}
              {event.available && selectedTicket?.available ? (
                <Button
                  onClick={handleAddToCart}
                  className="w-full bg-accent text-accent-foreground hover:bg-accent/90 mb-3 py-6 text-lg"
                >
                  Add to Cart
                </Button>
              ) : (
                <Button disabled className="w-full mb-3 py-6">
                  Sold Out
                </Button>
              )}

              <Link href="/cart" className="w-full">
                <Button variant="outline" className="w-full py-6 bg-transparent">
                  View Cart
                </Button>
              </Link>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}

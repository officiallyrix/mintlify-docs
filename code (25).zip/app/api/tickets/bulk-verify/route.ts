import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

interface BulkVerifyRequest {
  eventId: number
  staffId: string
  location: string
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const eventId = searchParams.get("eventId")

    if (!eventId) {
      return NextResponse.json(
        {
          success: false,
          error: "Event ID is required",
        },
        { status: 400 },
      )
    }

    const sql = neon(process.env.NEON_NEON_DATABASE_URL || process.env.DATABASE_URL || "")

    const stats = await sql(
      `SELECT 
        COUNT(*) as total_tickets,
        SUM(CASE WHEN scanned = true THEN 1 ELSE 0 END) as scanned_tickets,
        SUM(CASE WHEN status = 'used' THEN 1 ELSE 0 END) as used_tickets,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_tickets
      FROM tickets
      WHERE event_id = $1`,
      [eventId],
    )

    return NextResponse.json(
      {
        success: true,
        data: stats[0] || {
          total_tickets: 0,
          scanned_tickets: 0,
          used_tickets: 0,
          active_tickets: 0,
        },
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("[API] Error getting event stats:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to get event statistics",
      },
      { status: 500 },
    )
  }
}

import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

interface VerificationRequest {
  ticketId: string
  staffId?: string
  location?: string
}

interface VerificationResponse {
  success: boolean
  valid: boolean
  message: string
  ticketId?: string
  event?: string
  ticketType?: string
  customerName?: string
  scanned?: boolean
  error?: string
}

export async function POST(request: NextRequest): Promise<NextResponse<VerificationResponse>> {
  try {
    const body: VerificationRequest = await request.json()

    if (!body.ticketId) {
      return NextResponse.json(
        {
          success: false,
          valid: false,
          message: "Ticket ID is required",
          error: "MISSING_TICKET_ID",
        },
        { status: 400 },
      )
    }

    const sql = neon(process.env.NEON_NEON_DATABASE_URL || process.env.DATABASE_URL || "")

    // Query for ticket
    const ticketsResult = await sql(
      `SELECT 
        id, 
        ticket_id, 
        event_id, 
        customer_name, 
        customer_email, 
        ticket_type, 
        status, 
        scanned, 
        scanned_at
      FROM tickets 
      WHERE ticket_id = $1 AND status = 'active'`,
      [body.ticketId],
    )

    if (!ticketsResult || ticketsResult.length === 0) {
      return NextResponse.json(
        {
          success: true,
          valid: false,
          message: "Ticket not found or already used",
        },
        { status: 200 },
      )
    }

    const ticket = ticketsResult[0]

    // Check if already scanned
    if (ticket.scanned) {
      return NextResponse.json(
        {
          success: true,
          valid: false,
          message: "Ticket has already been scanned",
          ticketId: ticket.ticket_id,
        },
        { status: 200 },
      )
    }

    const scanTime = new Date().toISOString()
    const staffId = body.staffId || "automated_scan"

    // Update ticket status
    await sql(
      `UPDATE tickets 
      SET scanned = true, scanned_at = $1, scanned_by = $2, updated_at = NOW()
      WHERE ticket_id = $3`,
      [scanTime, staffId, body.ticketId],
    )

    // Log the scan
    await sql(
      `INSERT INTO ticket_scan_logs (ticket_id, scanned_by, scan_status, location, created_at)
      VALUES ($1, $2, $3, $4, NOW())`,
      [body.ticketId, staffId, "success", body.location || "venue"],
    )

    return NextResponse.json(
      {
        success: true,
        valid: true,
        message: "Ticket is valid and entry granted",
        ticketId: ticket.ticket_id,
        event: `Morgan Wallen Live - Event ${ticket.event_id}`,
        ticketType: ticket.ticket_type,
        customerName: ticket.customer_name,
        scanned: true,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("[API] Error verifying ticket:", error)
    return NextResponse.json(
      {
        success: false,
        valid: false,
        message: "Failed to verify ticket",
        error: "VERIFICATION_ERROR",
      },
      { status: 500 },
    )
  }
}

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const { searchParams } = new URL(request.url)
    const ticketId = searchParams.get("ticketId")
    const limit = searchParams.get("limit") || "50"

    if (!ticketId) {
      return NextResponse.json(
        {
          success: false,
          error: "Ticket ID is required",
        },
        { status: 400 },
      )
    }

    const sql = neon(process.env.NEON_DATABASE_URL || process.env.DATABASE_URL || "")

    const scanLogs = await sql(
      `SELECT 
        id,
        ticket_id,
        scanned_at,
        scanned_by,
        scan_status,
        location
      FROM ticket_scan_logs
      WHERE ticket_id = $1
      ORDER BY scanned_at DESC
      LIMIT $2`,
      [ticketId, limit],
    )

    return NextResponse.json(
      {
        success: true,
        data: scanLogs,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("[API] Error fetching scan logs:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch scan logs",
      },
      { status: 500 },
    )
  }
}

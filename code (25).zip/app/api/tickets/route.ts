import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const customerEmail = searchParams.get("email")

    if (!customerEmail) {
      return NextResponse.json(
        {
          success: false,
          error: "Customer email is required",
        },
        { status: 400 },
      )
    }

    const sql = neon(process.env.NEON_DATABASE_URL || process.env.DATABASE_URL || "")

    const tickets = await sql(
      `SELECT t.*, e.title as event_title, e.date, e.time, e.location 
       FROM tickets t
       LEFT JOIN events e ON t.event_id = e.id
       WHERE t.customer_email = $1
       ORDER BY t.created_at DESC`,
      [customerEmail],
    )

    return NextResponse.json(
      {
        success: true,
        data: tickets,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("[API] Error fetching tickets:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch tickets",
      },
      { status: 500 },
    )
  }
}

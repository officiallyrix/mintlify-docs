import { NextResponse } from "next/server"

const SUPPORT_SYSTEM_PROMPT = `You are a helpful customer support assistant for Morgan Wallen Live 2026 concert ticketing platform.

You help customers with:
- Ticket information and pricing
- Event dates and locations
- FAQs about booking and payment
- Order tracking and status
- General customer support questions

Be friendly, professional, and concise. Keep responses to 2-3 sentences max. If you don't know something, direct customers to support@morganwallenlive.com.

Common FAQs:
- Ticket prices range from $50-$500 depending on venue and seat location
- Events are available from January-December 2026 across major US cities
- We accept all major credit cards and digital payment methods
- Tickets are typically delivered 7-10 days before the event
- Refunds available up to 30 days before the event
- All sales are final for last-minute purchases within 7 days`

function generateSupportResponse(message: string): string {
  const lowerMessage = message.toLowerCase()

  // Ticket pricing queries
  if (lowerMessage.includes("price") || lowerMessage.includes("cost") || lowerMessage.includes("how much")) {
    return "Ticket prices range from $89 for General Admission to $249 for Premium VIP depending on the venue. Check our Events page to see specific pricing for each location!"
  }

  // Event/location queries
  if (lowerMessage.includes("when") || lowerMessage.includes("date") || lowerMessage.includes("where") || lowerMessage.includes("location")) {
    return "We have events from April 2026 through December 2026 in major cities worldwide including Minneapolis, London, Tokyo, and more. Visit our Events page to see the full schedule!"
  }

  // Payment queries
  if (lowerMessage.includes("pay") || lowerMessage.includes("payment") || lowerMessage.includes("credit card")) {
    return "We accept all major credit cards, Apple Pay, Google Pay, and PayPal. All transactions are secure and encrypted for your safety."
  }

  // Refund queries
  if (lowerMessage.includes("refund") || lowerMessage.includes("cancel") || lowerMessage.includes("return")) {
    return "Refunds are available up to 30 days before your event. For cancellations within 7 days of the event, all sales are final. Contact support@morganwallenlive.com for assistance."
  }

  // Ticket delivery queries
  if (lowerMessage.includes("ticket") && (lowerMessage.includes("receive") || lowerMessage.includes("get") || lowerMessage.includes("delivery"))) {
    return "Digital tickets are delivered to your email 7-10 days before the event. You'll receive a confirmation immediately after purchase!"
  }

  // VIP queries
  if (lowerMessage.includes("vip") || lowerMessage.includes("premium")) {
    return "VIP tickets include priority entry and premium seating for $159. Premium VIP adds meet-and-greet access for $249. Upgrade your experience today!"
  }

  // Order tracking
  if (lowerMessage.includes("order") || lowerMessage.includes("track") || lowerMessage.includes("status")) {
    return "You can track your order status by checking your email confirmation. For specific order inquiries, please email support@morganwallenlive.com with your order number."
  }

  // Default response
  return "Thanks for reaching out! For detailed assistance with your specific question, please email our support team at support@morganwallenlive.com or check out our FAQs on the website."
}

export async function POST(request: Request) {
  try {
    const { message } = await request.json()

    if (!message || message.trim().length === 0) {
      return NextResponse.json({ error: "Message is required" }, { status: 400 })
    }

    const timestamp = new Date().toISOString()

    const responseText = generateSupportResponse(message)

    const response = {
      success: true,
      message: responseText,
      timestamp,
    }

    return NextResponse.json(response, { status: 200 })
  } catch (error) {
    console.error("[v0] Chat API error:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Thanks for your message! Our support team will respond shortly. You can also email us at support@morganwallenlive.com",
        timestamp: new Date().toISOString(),
      },
      { status: 200 }
    )
  }
}

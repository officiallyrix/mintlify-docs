import "server-only"

import { headers } from "next/headers"
import { stripe } from "@/lib/stripe"
import { TICKET_PRODUCTS } from "@/lib/products"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { items } = body

    if (!items || items.length === 0) {
      return Response.json({ error: "No items in cart" }, { status: 400 })
    }

    // Validate products and build line items
    const lineItems = items.map((item: any) => {
      const product = TICKET_PRODUCTS.find((p) => p.id === item.id)
      if (!product) {
        throw new Error(`Product not found: ${item.id}`)
      }

      return {
        price_data: {
          currency: "usd",
          product_data: {
            name: `${product.ticketType} - ${product.eventTitle}`,
            description: `${product.venue} - ${product.date}`,
          },
          unit_amount: product.priceInCents,
        },
        quantity: item.quantity,
      }
    })

    // Create Stripe checkout session
    const origin = headers().get("origin") || process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000"
    const session = await stripe.checkout.sessions.create({
      ui_mode: "embedded",
      redirect_on_completion: "never",
      line_items: lineItems,
      mode: "payment",
      return_url: `${origin}/checkout-return?session_id={CHECKOUT_SESSION_ID}`,
    })

    return Response.json({ clientSecret: session.client_secret })
  } catch (error) {
    console.error("Checkout error:", error)
    return Response.json({ error: error instanceof Error ? error.message : "Checkout failed" }, { status: 500 })
  }
}

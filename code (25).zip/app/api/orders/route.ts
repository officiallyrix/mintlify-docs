import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"
import { validateEmail, validatePhoneNumber } from "@/lib/validation"

interface CartItem {
  eventId: number
  title: string
  ticketType: string
  price: number
  quantity: number
}

interface OrderPayload {
  firstName: string
  lastName: string
  email: string
  phone: string
  items: CartItem[]
}

export async function GET(request: NextRequest) {
  try {
    const sql = neon(process.env.NEON_DATABASE_URL || process.env.DATABASE_URL || "")

    const orders = await sql("SELECT * FROM orders ORDER BY created_at DESC LIMIT 100")

    return NextResponse.json(
      {
        success: true,
        data: orders,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("[API] Error fetching orders:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch orders",
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: OrderPayload = await request.json()

    // Validate input
    if (!body.email || !body.firstName || !body.lastName || !body.items || body.items.length === 0) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing required fields",
        },
        { status: 400 },
      )
    }

    if (!validateEmail(body.email)) {
      return NextResponse.json(
        {
          success: false,
          error: "Invalid email address",
        },
        { status: 400 },
      )
    }

    if (!validatePhoneNumber(body.phone)) {
      return NextResponse.json(
        {
          success: false,
          error: "Invalid phone number",
        },
        { status: 400 },
      )
    }

    const sql = neon(process.env.NEON_DATABASE_URL || process.env.DATABASE_URL || "")

    // Calculate order totals
    const subtotal = body.items.reduce((sum, item) => sum + item.price * item.quantity, 0)
    const fees = subtotal * 0.1
    const total = subtotal + fees

    // Generate confirmation number
    const confirmationNumber = `MWALL${Date.now().toString().slice(-8).toUpperCase()}`

    const orderResult = await sql(
      `INSERT INTO orders (confirmation_number, customer_name, customer_email, customer_phone, subtotal, fees, total, status, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW())
      RETURNING id, confirmation_number, customer_name, customer_email, customer_phone, subtotal, fees, total, status, created_at`,
      [
        confirmationNumber,
        `${body.firstName} ${body.lastName}`,
        body.email,
        body.phone,
        subtotal,
        fees,
        total,
        "confirmed",
      ],
    )

    if (!orderResult || orderResult.length === 0) {
      throw new Error("Failed to create order in database")
    }

    const order = orderResult[0]

    for (const item of body.items) {
      await sql(
        `INSERT INTO order_items (order_id, event_id, ticket_type, quantity, price, created_at)
        VALUES ($1, $2, $3, $4, $5, NOW())`,
        [order.id, item.eventId, item.ticketType, item.quantity, item.price],
      )

      for (let i = 0; i < item.quantity; i++) {
        const ticketId = `${confirmationNumber}-${item.eventId}-${item.ticketType}-${i + 1}`
        await sql(
          `INSERT INTO tickets (ticket_id, order_id, event_id, customer_name, customer_email, ticket_type, price, status, scanned, qr_code_data, created_at, updated_at)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW(), NOW())`,
          [
            ticketId,
            order.id,
            item.eventId,
            `${body.firstName} ${body.lastName}`,
            body.email,
            item.ticketType,
            item.price,
            "active",
            false,
            ticketId, // qr_code_data can be used to generate actual QR codes
          ],
        )
      }
    }

    try {
      await sendConfirmationEmail(body.email, confirmationNumber, `${body.firstName} ${body.lastName}`, total)
    } catch (emailError) {
      console.error("[API] Email sending failed (non-blocking):", emailError)
      // Don't fail the order if email fails
    }

    console.log("[API] Order created:", confirmationNumber)

    return NextResponse.json(
      {
        success: true,
        data: {
          id: order.id,
          confirmationNumber: order.confirmation_number,
          customerName: order.customer_name,
          customerEmail: order.customer_email,
          customerPhone: order.customer_phone,
          items: body.items,
          subtotal: order.subtotal,
          fees: order.fees,
          total: order.total,
          status: order.status,
          createdAt: order.created_at,
        },
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("[API] Error creating order:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Failed to create order",
      },
      { status: 500 },
    )
  }
}

async function sendConfirmationEmail(
  email: string,
  confirmationNumber: string,
  customerName: string,
  total: number,
): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY || process.env.SENDGRID_API_KEY
  if (!apiKey) {
    console.warn("[EMAIL] No email service configured")
    return
  }

  // Using Resend (priority over SendGrid)
  if (process.env.RESEND_API_KEY) {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: process.env.RESEND_FROM_EMAIL || "noreply@morganwallenlive.com",
        to: email,
        subject: "Morgan Wallen Live - Order Confirmation",
        html: `
          <html>
            <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h1>Order Confirmation</h1>
              <p>Dear ${customerName},</p>
              <p>Thank you for your order! Your confirmation number is:</p>
              <h2 style="color: #00d9ff; font-size: 24px;">${confirmationNumber}</h2>
              <p>Total Amount: <strong>$${total.toFixed(2)}</strong></p>
              <p>You can view your tickets at: <a href="https://morganwallenlive.com/my-tickets">My Tickets</a></p>
              <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
              <p>Best regards,<br>Morgan Wallen Live Team</p>
            </body>
          </html>
        `,
      }),
    })

    if (!response.ok) {
      throw new Error(`Email service error: ${response.statusText}`)
    }
  }
}

import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

export async function GET(request: NextRequest) {
  try {
    const sql = neon(process.env.NEON_DATABASE_URL || process.env.DATABASE_URL || "")

    // Fetch events from database instead of hardcoded mock data
    const events = await sql("SELECT * FROM events ORDER BY date DESC")

    return NextResponse.json(
      {
        success: true,
        data: events,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("[API] Error fetching events:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch events",
      },
      { status: 500 },
    )
  }
}

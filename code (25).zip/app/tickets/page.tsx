"use client"

import TicketSample from "@/components/ticket-sample"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const ticketSamples = [
  {
    id: 1,
    eventId: 1,
    eventTitle: "Minneapolis, MN",
    venue: "U.S. Bank Stadium",
    date: "Apr 10, 2026",
    time: "8:00 PM",
    ticketType: "General Admission" as const,
    price: 89,
    ticketNumber: "MW-GA-001-2026-4391",
    holderName: "Sample Attendee",
  },
  {
    id: 2,
    eventId: 1,
    eventTitle: "Minneapolis, MN",
    venue: "U.S. Bank Stadium",
    date: "Apr 10, 2026",
    time: "8:00 PM",
    ticketType: "VIP" as const,
    price: 159,
    ticketNumber: "MW-VIP-001-2026-5847",
    holderName: "Sample VIP Guest",
  },
  {
    id: 3,
    eventId: 1,
    eventTitle: "Minneapolis, MN",
    venue: "U.S. Bank Stadium",
    date: "Apr 10, 2026",
    time: "8:00 PM",
    ticketType: "Premium VIP" as const,
    price: 249,
    ticketNumber: "MW-PVIP-001-2026-7263",
    holderName: "Premium Member",
  },
  {
    id: 4,
    eventId: 24,
    eventTitle: "London, UK",
    venue: "The O2",
    date: "Aug 15, 2026",
    time: "8:00 PM",
    ticketType: "General Admission" as const,
    price: 95,
    ticketNumber: "MW-GA-002-2026-5821",
    holderName: "Sample Attendee",
  },
  {
    id: 5,
    eventId: 24,
    eventTitle: "London, UK",
    venue: "The O2",
    date: "Aug 15, 2026",
    time: "8:00 PM",
    ticketType: "VIP" as const,
    price: 175,
    ticketNumber: "MW-VIP-002-2026-6394",
    holderName: "Sample VIP Guest",
  },
  {
    id: 6,
    eventId: 36,
    eventTitle: "Tokyo, Japan",
    venue: "Nippon Budokan",
    date: "Oct 30, 2026",
    time: "8:00 PM",
    ticketType: "Premium VIP" as const,
    price: 319,
    ticketNumber: "MW-PVIP-002-2026-9147",
    holderName: "Premium Member",
  },
]

export default function TicketsPage() {
  return (
    <main className="min-h-screen bg-background pt-24 pb-12">
      <div className="max-w-6xl mx-auto px-4">
        {/* Tabs for different filters */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="all">All Tickets</TabsTrigger>
            <TabsTrigger value="general">General Admission</TabsTrigger>
            <TabsTrigger value="vip">VIP</TabsTrigger>
            <TabsTrigger value="premium">Premium VIP</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-6">
            {ticketSamples.map((ticket) => (
              <TicketSample key={ticket.id} {...ticket} />
            ))}
          </TabsContent>

          <TabsContent value="general" className="space-y-6">
            {ticketSamples
              .filter((t) => t.ticketType === "General Admission")
              .map((ticket) => (
                <TicketSample key={ticket.id} {...ticket} />
              ))}
          </TabsContent>

          <TabsContent value="vip" className="space-y-6">
            {ticketSamples
              .filter((t) => t.ticketType === "VIP")
              .map((ticket) => (
                <TicketSample key={ticket.id} {...ticket} />
              ))}
          </TabsContent>

          <TabsContent value="premium" className="space-y-6">
            {ticketSamples
              .filter((t) => t.ticketType === "Premium VIP")
              .map((ticket) => (
                <TicketSample key={ticket.id} {...ticket} />
              ))}
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}

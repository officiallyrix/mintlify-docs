import Header from "@/components/header"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export const metadata = {
  title: "About Morgan Wallen Live Tour 2026",
  description:
    "Learn about Morgan Wallen and his 2026 live tour. Premium venues, world-class production, and unforgettable country music experiences.",
}

export default function About() {
  return (
    <main className="min-h-screen bg-background">
      <Header />

      {/* Hero Banner with Profile Image */}
      <section className="relative py-12 px-4 bg-gradient-to-b from-primary/30 to-background">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 items-center mb-16">
            {/* Profile Image */}
            <div className="md:col-span-1 flex justify-center">
              <div className="relative w-full aspect-square rounded-lg overflow-hidden border-2 border-accent/50 shadow-lg">
                <img
                  src="/morgan-wallen-concert-stage-lights.jpg"
                  alt="Morgan Wallen"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Hero Text */}
            <div className="md:col-span-2">
              <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-4 text-balance">Morgan Wallen</h1>
              <p className="text-lg text-accent font-semibold mb-4">Country Music's Crossover Superstar</p>
              <p className="text-xl text-muted-foreground leading-relaxed mb-6">
                Born May 13, 1993 in Sneedville, Tennessee, Morgan Cole Wallen has become one of the most electrifying
                forces in modern country music. With chart-topping albums, platinum certifications, and millions of
                dedicated fans worldwide, Morgan continues to push the boundaries of country music while honoring its
                authentic roots.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Early Life & Career */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold text-foreground mb-8 text-balance">Early Life & Career</h2>
            <div className="grid md:grid-cols-2 gap-12 items-start">
              <div>
                <div className="bg-card border border-border rounded-lg p-8 shadow-lg">
                  <h3 className="text-2xl font-bold text-accent mb-4">Musical Roots</h3>
                  <p className="text-muted-foreground leading-relaxed mb-4">
                    Morgan grew up in Sneedville, Tennessee, where his father Tommy was a pastor and his mother Lesli
                    was a teacher. From age 3, he sang in church, and by age 5 he had begun learning violin, piano, and
                    guitar. Music was woven into the fabric of his childhood.
                  </p>
                  <p className="text-muted-foreground leading-relaxed">
                    In high school, Morgan excelled at baseball as a shortstop and pitcher until a UCL elbow injury
                    ended that athletic path, ultimately leading him to pursue music full-time with renewed dedication.
                  </p>
                </div>
              </div>
              <div>
                <div className="bg-card border border-border rounded-lg p-8 shadow-lg">
                  <h3 className="text-2xl font-bold text-accent mb-4">The Voice & Beyond</h3>
                  <p className="text-muted-foreground leading-relaxed mb-4">
                    In 2014, at age 21, Morgan auditioned for Season 6 of NBC's "The Voice," showcasing his powerful
                    vocals on a national platform. Though eliminated in the playoffs, the exposure accelerated his music
                    career significantly.
                  </p>
                  <p className="text-muted-foreground leading-relaxed">
                    After The Voice, he signed with Panacea Records and released his debut EP "Stand Alone" in 2015,
                    establishing himself as a rising talent in country music with authentic storytelling and emotional
                    depth.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Discography */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold text-foreground mb-8 text-balance">Discography</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-card border border-border rounded-lg p-8 shadow-lg hover:border-accent/50 transition">
                <h3 className="text-2xl font-bold text-accent mb-4">Studio Albums</h3>
                <ul className="space-y-4 text-muted-foreground">
                  <li className="border-b border-border pb-3">
                    <div className="font-bold text-foreground">If I Know Me (2018)</div>
                    <p className="text-sm">Major label debut featuring breakthrough hits</p>
                  </li>
                  <li className="border-b border-border pb-3">
                    <div className="font-bold text-foreground">Dangerous: The Double Album (2021)</div>
                    <p className="text-sm">Landmark release debuting at #1 on Billboard 200</p>
                  </li>
                  <li className="border-b border-border pb-3">
                    <div className="font-bold text-foreground">One Thing at a Time (2023)</div>
                    <p className="text-sm">36-track album with record-breaking chart performance</p>
                  </li>
                  <li>
                    <div className="font-bold text-foreground">I'm the Problem (2025)</div>
                    <p className="text-sm">Latest studio album released May 16, 2025</p>
                  </li>
                </ul>
              </div>

              <div className="bg-card border border-border rounded-lg p-8 shadow-lg hover:border-accent/50 transition">
                <h3 className="text-2xl font-bold text-accent mb-4">Chart Milestones</h3>
                <ul className="space-y-4 text-muted-foreground">
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">✓</span>
                    <span>"Last Night" - First Billboard Hot 100 #1 hit</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">✓</span>
                    <span>Multiple top-10 and chart-topping singles</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">✓</span>
                    <span>Dangerous: The Double Album - #1 US Billboard 200</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">✓</span>
                    <span>One Thing at a Time - Record-breaking weeks at #1</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">✓</span>
                    <span>2024 CMA Entertainer of the Year Award</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Performance Gallery */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold text-foreground mb-8 text-balance">Live Performances</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="relative aspect-video rounded-lg overflow-hidden border border-border shadow-lg hover:border-accent/50 transition">
                <img
                  src="/country-music-stadium-concert.jpg"
                  alt="Morgan Wallen performing on stage"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="relative aspect-video rounded-lg overflow-hidden border border-border shadow-lg hover:border-accent/50 transition">
                <img
                  src="/live-concert-performance-crowd.jpg"
                  alt="Morgan Wallen at concert with crowd"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="relative aspect-video rounded-lg overflow-hidden border border-border shadow-lg hover:border-accent/50 transition">
                <img
                  src="/music-festival-outdoor-stage.jpg"
                  alt="Morgan Wallen with acoustic guitar"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>

          {/* Awards & Recognition */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold text-foreground mb-8 text-balance">Awards & Recognition</h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-accent/20 to-primary/20 border border-accent/30 rounded-lg p-8 text-center shadow-lg">
                <div className="text-4xl font-bold text-accent mb-2">2024</div>
                <p className="text-foreground font-semibold">CMA Entertainer of the Year</p>
                <p className="text-sm text-muted-foreground mt-2">Highest honor in country music</p>
              </div>
              <div className="bg-gradient-to-br from-accent/20 to-primary/20 border border-accent/30 rounded-lg p-8 text-center shadow-lg">
                <div className="text-4xl font-bold text-accent mb-2">Multi-Platinum</div>
                <p className="text-foreground font-semibold">Recording Certifications</p>
                <p className="text-sm text-muted-foreground mt-2">RIAA platinum & gold awards</p>
              </div>
              <div className="bg-gradient-to-br from-accent/20 to-primary/20 border border-accent/30 rounded-lg p-8 text-center shadow-lg">
                <div className="text-4xl font-bold text-accent mb-2">Millions</div>
                <p className="text-foreground font-semibold">Streaming & Social Following</p>
                <p className="text-sm text-muted-foreground mt-2">Global fanbase across platforms</p>
              </div>
            </div>
          </div>

          {/* Philanthropy & Foundation */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold text-foreground mb-8 text-balance">Morgan Wallen Foundation</h2>
            <div className="bg-card border border-border rounded-lg p-8 shadow-lg">
              <p className="text-lg text-muted-foreground leading-relaxed mb-4">
                Morgan is committed to giving back to the community through the Morgan Wallen Foundation, which provides
                young people with opportunities in music and sports. His philanthropic efforts reflect his values of
                community support and developing the next generation of talented individuals.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Through various charitable initiatives and community partnerships, Morgan continues to make a positive
                impact beyond the stage, demonstrating that his influence extends far into the lives of fans and
                aspiring artists worldwide.
              </p>
            </div>
          </div>

          {/* Statistics */}
          <div className="bg-card border border-border rounded-lg p-8 mb-16 shadow-lg">
            <h2 className="text-3xl font-bold text-foreground mb-6">2026 Tour by the Numbers</h2>
            <div className="grid md:grid-cols-4 gap-8">
              <div>
                <div className="text-4xl font-bold text-accent mb-2">50+</div>
                <p className="text-muted-foreground">Tour Dates</p>
              </div>
              <div>
                <div className="text-4xl font-bold text-accent mb-2">1M+</div>
                <p className="text-muted-foreground">Fans Expected</p>
              </div>
              <div>
                <div className="text-4xl font-bold text-accent mb-2">$100M+</div>
                <p className="text-muted-foreground">Projected Tour Revenue</p>
              </div>
              <div>
                <div className="text-4xl font-bold text-accent mb-2">99%</div>
                <p className="text-muted-foreground">Fan Satisfaction Rate</p>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="text-center">
            <h2 className="text-3xl font-bold text-foreground mb-6">Ready to Experience Morgan Wallen Live?</h2>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
              Browse our complete lineup of 2026 tour dates and secure your tickets for an unforgettable night of live
              country music.
            </p>
            <Link href="/#events">
              <Button size="lg" className="btn-primary">
                Browse Events
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </main>
  )
}

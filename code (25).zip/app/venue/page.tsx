"use client"

import { useState } from "react"
import Image from "next/image"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

export default function VenuePage() {
  const [selectedSection, setSelectedSection] = useState<string | null>(null)

  const sections = [
    { id: "premium", name: "Premium Floor Seats", price: "$986", availability: "12 left", color: "bg-green-500" },
    { id: "vip", name: "VIP Lower Bowl", price: "$502-$550", availability: "4-6 left", color: "bg-green-500" },
    { id: "mid", name: "Mid-Level Seating", price: "$296-$416", availability: "2-10 left", color: "bg-green-500" },
    { id: "upper", name: "Upper Level", price: "$172-$243", availability: "2-4 left", color: "bg-green-500" },
    { id: "standing", name: "Standing Room Only", price: "$821", availability: "2 left", color: "bg-yellow-500" },
  ]

  return (
    <main className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Main Seating Chart */}
          <div className="lg:col-span-2">
            <Card className="overflow-hidden bg-card border border-border">
              <CardHeader className="bg-primary/10 border-b border-border">
                <CardTitle>Interactive Seating Map</CardTitle>
                <CardDescription>Click on sections to view pricing and availability</CardDescription>
              </CardHeader>
              <CardContent className="p-0 bg-card">
                <div className="relative w-full aspect-square flex items-center justify-center">
                  <img
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/venue-n0qZYcsvfBv7zYmlyjxDHwZgHpB5cy.png"
                    alt="Venue Seating Chart - Morgan Wallen Tour 2026"
                    className="w-full h-auto object-contain p-6"
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - Section Details */}
          <div className="lg:col-span-1 space-y-4">
            <Card className="bg-card border border-border sticky top-20">
              <CardHeader className="bg-primary/10 border-b border-border">
                <CardTitle className="text-xl">Section Details</CardTitle>
              </CardHeader>
              <CardContent className="pt-6 space-y-4">
                {sections.map((section) => (
                  <button
                    key={section.id}
                    onClick={() => setSelectedSection(section.id)}
                    className={`w-full text-left p-4 rounded-lg border-2 transition-all duration-200 ${
                      selectedSection === section.id
                        ? "border-accent bg-accent/10"
                        : "border-border hover:border-accent/50 bg-muted/30"
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-foreground text-sm">{section.name}</h3>
                      <Badge className="bg-accent text-accent-foreground ml-2">{section.color}</Badge>
                    </div>
                    <p className="text-accent font-bold text-lg mb-1">{section.price}</p>
                    <p className="text-muted-foreground text-xs">{section.availability}</p>
                  </button>
                ))}
              </CardContent>
            </Card>

            {/* Legend */}
            <Card className="bg-card border border-border">
              <CardHeader className="bg-primary/10 border-b border-border pb-3">
                <CardTitle className="text-sm">Legend</CardTitle>
              </CardHeader>
              <CardContent className="pt-4 space-y-3 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-green-500"></div>
                  <span className="text-foreground">Available Sections</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-gray-400"></div>
                  <span className="text-foreground">Sold Out</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Venue Information */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-card border border-border">
            <CardHeader className="bg-primary/10 border-b border-border">
              <CardTitle className="text-lg">Capacity</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <p className="text-3xl font-bold text-accent">18,500+</p>
              <p className="text-muted-foreground text-sm mt-1">Total Seats Available</p>
            </CardContent>
          </Card>

          <Card className="bg-card border border-border">
            <CardHeader className="bg-primary/10 border-b border-border">
              <CardTitle className="text-lg">Best Views</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <p className="text-foreground font-semibold mb-2">Lower Bowl Sections</p>
              <p className="text-muted-foreground text-sm">Premium sightlines and stage proximity</p>
            </CardContent>
          </Card>

          <Card className="bg-card border border-border">
            <CardHeader className="bg-primary/10 border-b border-border">
              <CardTitle className="text-lg">Accessibility</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <p className="text-foreground font-semibold mb-2">ADA Compliant</p>
              <p className="text-muted-foreground text-sm">Wheelchair access available throughout</p>
            </CardContent>
          </Card>
        </div>

        {/* CTA Section */}
        <div className="mt-12 text-center bg-gradient-to-r from-primary/20 to-accent/20 border border-accent/30 rounded-lg p-8">
          <h2 className="text-2xl font-bold text-foreground mb-2">Ready to Experience Morgan Wallen Live?</h2>
          <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
            Select your preferred section and complete your ticket purchase to secure your spot at the hottest tour of
            2026
          </p>
          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-2 text-base rounded-lg neon-shadow-accent-button">
            Browse Tickets
          </Button>
        </div>
      </div>
    </main>
  )
}

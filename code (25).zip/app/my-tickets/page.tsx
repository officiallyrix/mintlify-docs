"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Header from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Download, Ticket } from "lucide-react"

interface StripeOrder {
  id: string
  sessionId: string
  items: Array<{
    eventTitle: string
    venue: string
    date: string
    time: string
    ticketType: string
    quantity: number
    price: number
  }>
  total: number
  orderDate: string
}

interface LegacyOrder {
  confirmationNumber: string
  customerName: string
  customerEmail: string
  customerPhone: string
  items: Array<{
    eventId: number
    title: string
    ticketType: string
    price: number
    quantity: number
  }>
  orderDate: string
  subtotal: number
  fees: number
  total: number
}

type Order = StripeOrder | LegacyOrder

export default function MyTicketsPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Load both Stripe orders and legacy orders
    const stripeOrders = JSON.parse(localStorage.getItem("stripe_orders") || "[]")
    const legacyOrders = JSON.parse(localStorage.getItem("orders") || "[]")
    setOrders([...stripeOrders, ...legacyOrders])
    setIsLoading(false)
  }, [])

  if (isLoading) {
    return (
      <main className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-24 text-center">
          <p className="text-muted-foreground">Loading your tickets...</p>
        </div>
      </main>
    )
  }

  if (orders.length === 0) {
    return (
      <main className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-24 text-center">
          <h1 className="text-4xl font-bold text-foreground mb-4">No Tickets Yet</h1>
          <p className="text-muted-foreground mb-8">You haven't purchased any tickets yet.</p>
          <Link href="/">
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Browse Events
            </Button>
          </Link>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="mb-8">
          <Link href="/">
            <Button variant="outline" className="mb-6 bg-transparent">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-4xl font-bold text-foreground text-balance">My Tickets</h1>
        </div>

        <div className="space-y-6">
          {orders.map((order, idx) => (
            <Card key={idx} className="p-8 border-border">
              {/* Order Header */}
              <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-4 mb-6 pb-6 border-b border-border">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Order ID</p>
                  <p className="text-2xl font-bold text-accent">
                    {"confirmationNumber" in order ? order.confirmationNumber : order.sessionId}
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">
                    {new Date(order.orderDate).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground mb-1">Total Amount</p>
                  <p className="text-2xl font-bold text-foreground">${order.total.toFixed(2)}</p>
                </div>
              </div>

              {/* Tickets */}
              <div className="space-y-4 mb-6">
                {"items" in order &&
                  order.items.map((item, index) => (
                    <TicketCard
                      key={`${idx}-${index}`}
                      orderId={"confirmationNumber" in order ? order.confirmationNumber : order.sessionId}
                      ticketNumber={index + 1}
                      event={"eventTitle" in item ? item.eventTitle : item.title}
                      venue={"venue" in item ? item.venue : ""}
                      date={"date" in item ? item.date : ""}
                      time={"time" in item ? item.time : ""}
                      ticketType={item.ticketType}
                      quantity={item.quantity}
                    />
                  ))}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </main>
  )
}

interface TicketCardProps {
  orderId: string
  ticketNumber: number
  event: string
  venue: string
  date: string
  time: string
  ticketType: string
  quantity: number
}

function TicketCard({ orderId, ticketNumber, event, venue, date, time, ticketType, quantity }: TicketCardProps) {
  const ticketId = `${orderId}-T${ticketNumber}`

  const ticketColors = {
    "General Admission": { stripe: "bg-blue-600", accent: "text-blue-400" },
    VIP: { stripe: "bg-purple-600", accent: "text-purple-400" },
    "Premium VIP": { stripe: "bg-amber-600", accent: "text-amber-400" },
  }

  const colors =
    ticketColors[ticketType as "General Admission" | "VIP" | "Premium VIP"] || ticketColors["General Admission"]

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-start gap-3">
          <Ticket className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
          <div>
            <p className="font-semibold text-foreground">{event}</p>
            <p className="text-sm text-muted-foreground">{venue}</p>
            <p className="text-sm text-muted-foreground">
              {date} at {time}
            </p>
            <p className="text-sm text-accent font-semibold mt-1">{ticketType}</p>
            <p className="text-xs text-muted-foreground mt-1">Qty: {quantity}</p>
          </div>
        </div>

        <Button variant="outline" size="sm" className="flex items-center gap-2 bg-transparent">
          <Download className="w-4 h-4" />
          Download
        </Button>
      </div>

      <div className="mt-4 overflow-auto">
        <div
          className="border-2 border-yellow-600/40 rounded-lg overflow-hidden bg-cover bg-center relative"
          style={{
            backgroundImage: "url('/ticket-background.jpg')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            minHeight: "350px",
          }}
        >
          <div className="absolute inset-0 bg-black/40"></div>

          <div className="relative p-8 text-white h-full flex flex-col justify-between">
            {/* Top Section */}
            <div className="flex justify-between items-start mb-8">
              <div>
                <h4 className="text-2xl font-black tracking-widest">MORGAN WALLEN</h4>
                <p className="text-xs opacity-75 mt-1 tracking-wide">STILL THE PROBLEM TOUR 2026</p>
              </div>
              <div className={`${colors.stripe} text-white px-4 py-1 rounded text-xs font-black`}>{ticketType}</div>
            </div>

            {/* Event Information */}
            <div className="grid grid-cols-2 gap-6 mb-8 pb-8 border-b border-white/30">
              <div>
                <p className="text-xs opacity-70 font-semibold mb-1 tracking-widest uppercase">Event</p>
                <p className="font-bold text-sm">{event}</p>
              </div>
              <div>
                <p className="text-xs opacity-70 font-semibold mb-1 tracking-widest uppercase">Venue</p>
                <p className="font-bold text-sm">{venue}</p>
              </div>
              <div>
                <p className="text-xs opacity-70 font-semibold mb-1 tracking-widest uppercase">Date</p>
                <p className="font-bold text-sm">{date}</p>
              </div>
              <div>
                <p className="text-xs opacity-70 font-semibold mb-1 tracking-widest uppercase">Time</p>
                <p className="font-bold text-sm">{time}</p>
              </div>
            </div>

            {/* Admit One Section */}
            <div className="border-t border-white/30 pt-4">
              <p className="text-xs opacity-70 font-semibold mb-2 tracking-widest uppercase">Admit One</p>
              <p className="font-bold text-lg">{ticketId}</p>
            </div>
          </div>

          <div className={`${colors.stripe} h-2`}></div>
        </div>
      </div>
    </div>
  )
}

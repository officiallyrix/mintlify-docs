"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Header from "@/components/header"
import SeatSelector from "@/components/seat-selector"
import { events } from "@/lib/events-data"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import { useCart } from "@/components/cart-context"

export default function EventDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { addItem } = useCart()
  const [showNotification, setShowNotification] = useState(false)

  const event = events.find((e) => e.id === Number.parseInt(params.id))

  if (!event) {
    return (
      <main className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-24 text-center">
          <h1 className="text-4xl font-bold text-foreground mb-4">Event Not Found</h1>
          <Link href="/">
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Events
            </Button>
          </Link>
        </div>
      </main>
    )
  }

  const handleSelectTicket = (ticketType: string, quantity: number) => {
    const ticketInfo = event.ticketTypes.find((t) => t.type === ticketType)
    if (ticketInfo) {
      addItem({
        eventId: event.id,
        eventTitle: event.title,
        venue: event.location,
        date: event.date,
        time: event.time,
        ticketType,
        price: ticketInfo.price,
        quantity,
      })
      setShowNotification(true)
      setTimeout(() => setShowNotification(false), 3000)
    }
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-12">
        <Link href="/">
          <Button variant="outline" className="mb-6 bg-transparent">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Events
          </Button>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Event Details */}
          <div className="lg:col-span-2">
            <img
              src={event.image || "/placeholder.svg"}
              alt={event.title}
              className="w-full h-96 object-cover rounded-lg mb-6"
            />
            <h1 className="text-4xl font-bold text-foreground mb-4">{event.title}</h1>
            <p className="text-lg text-muted-foreground mb-6">{event.description}</p>

            <div className="grid grid-cols-2 gap-4 mb-8">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Date</p>
                <p className="text-lg font-semibold text-foreground">{event.date}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Time</p>
                <p className="text-lg font-semibold text-foreground">{event.time}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Venue</p>
                <p className="text-lg font-semibold text-foreground">{event.location}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Capacity</p>
                <p className="text-lg font-semibold text-foreground">{event.capacity.toLocaleString()}</p>
              </div>
            </div>

            <div className="bg-accent/5 p-6 rounded-lg border border-accent/20">
              <h3 className="text-lg font-bold text-foreground mb-4">About This Event</h3>
              <p className="text-muted-foreground mb-4">{event.description}</p>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Seats Available</p>
                  <p className="text-2xl font-bold text-accent">{event.seats_available.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Rating</p>
                  <p className="text-2xl font-bold text-accent">{event.rating}/5.0</p>
                </div>
              </div>
            </div>
          </div>

          {/* Seat Selector */}
          <div className="lg:col-span-1">
            {showNotification && (
              <div className="mb-4 p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                <p className="text-green-600 font-semibold">Added to cart successfully!</p>
              </div>
            )}
            <SeatSelector
              eventId={event.id}
              eventTitle={event.title}
              venue={event.location}
              date={event.date}
              time={event.time}
              ticketTypes={event.ticketTypes}
              onSelectTicket={handleSelectTicket}
            />
            <Link href="/cart" className="w-full mt-4 block">
              <Button variant="outline" className="w-full bg-transparent">
                View Cart
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </main>
  )
}

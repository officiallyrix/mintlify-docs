"use client"
import Header from "@/components/header"
import { Button } from "@/components/ui/button"
import EventGrid from "@/components/event-grid"
import Link from "next/link"
import { useState } from "react"

export default function Events() {
  const [eventType, setEventType] = useState<"all" | "concerts" | "football">("all")

  return (
    <main className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="relative py-20 px-4 bg-gradient-to-b from-primary/30 to-background">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-4 text-balance neon-text">
              Events & Tickets
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              Experience amazing events. Browse Morgan Wallen concerts and football matches, and secure your tickets for unforgettable moments.
            </p>
          </div>
        </div>
      </section>

      <section className="px-4 py-8 max-w-7xl mx-auto">
        <div className="flex gap-4 justify-center flex-wrap">
          <Button
            onClick={() => setEventType("all")}
            className={eventType === "all" ? "bg-accent text-accent-foreground" : "bg-accent/20 text-foreground hover:bg-accent/30"}
          >
            All Events
          </Button>
          <Button
            onClick={() => setEventType("concerts")}
            className={eventType === "concerts" ? "bg-accent text-accent-foreground" : "bg-accent/20 text-foreground hover:bg-accent/30"}
          >
            Concerts
          </Button>
          <Button
            onClick={() => setEventType("football")}
            className={eventType === "football" ? "bg-accent text-accent-foreground" : "bg-accent/20 text-foreground hover:bg-accent/30"}
          >
            Football Matches
          </Button>
        </div>
      </section>

      {/* Events Grid Section */}
      <section className="px-4 py-24 max-w-7xl mx-auto">
        <EventGrid eventType={eventType} />
      </section>

      {/* Footer CTA */}
      <section className="px-4 py-16 bg-gradient-to-t from-primary/30 to-background">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-foreground mb-4">Explore More</h2>
          <Link href="/merchandise">
            <Button size="lg" className="btn-primary">
              Shop Merchandise
            </Button>
          </Link>
        </div>
      </section>
    </main>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface VerificationResult {
  success: boolean
  valid: boolean
  message: string
  ticketId?: string
  customerName?: string
  ticketType?: string
}

export default function TicketVerificationPage() {
  const [ticketId, setTicketId] = useState("")
  const [result, setResult] = useState<VerificationResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [staffId, setStaffId] = useState("staff-001")

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult(null)

    try {
      const response = await fetch("/api/tickets/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ticketId: ticketId.trim(),
          staffId,
          location: "main-entrance",
        }),
      })

      const data: VerificationResult = await response.json()
      setResult(data)

      if (data.valid) {
        // Clear input on successful scan
        setTicketId("")
      }
    } catch (error) {
      console.error("Verification error:", error)
      setResult({
        success: false,
        valid: false,
        message: "Failed to verify ticket. Please try again.",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-background p-4">
      <div className="max-w-2xl mx-auto py-12">
        <h1 className="text-4xl font-bold text-foreground mb-2">Ticket Verification</h1>
        <p className="text-muted-foreground mb-8">Scan or enter ticket IDs to verify entry</p>

        <Card className="p-8 mb-6">
          <form onSubmit={handleVerify} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Staff ID</label>
              <Input
                type="text"
                value={staffId}
                onChange={(e) => setStaffId(e.target.value)}
                placeholder="Enter staff ID"
                className="bg-white text-foreground"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Ticket ID</label>
              <Input
                type="text"
                value={ticketId}
                onChange={(e) => setTicketId(e.target.value)}
                placeholder="Scan or enter ticket ID (e.g., MWALL12345678)"
                className="bg-white text-foreground text-lg font-mono"
                autoFocus
                disabled={loading}
              />
            </div>

            <Button type="submit" disabled={loading || !ticketId.trim()} className="w-full">
              {loading ? "Verifying..." : "Verify Ticket"}
            </Button>
          </form>
        </Card>

        {result && (
          <Alert
            className={`mb-6 ${
              result.valid
                ? "bg-green-50 border-green-200"
                : result.success
                  ? "bg-yellow-50 border-yellow-200"
                  : "bg-red-50 border-red-200"
            }`}
          >
            <AlertDescription
              className={result.valid ? "text-green-800" : result.success ? "text-yellow-800" : "text-red-800"}
            >
              <p className="font-semibold mb-2">{result.message}</p>
              {result.valid && (
                <div className="text-sm space-y-1">
                  <p>Customer: {result.customerName}</p>
                  <p>Ticket Type: {result.ticketType}</p>
                  <p>Ticket ID: {result.ticketId}</p>
                </div>
              )}
            </AlertDescription>
          </Alert>
        )}

        <Card className="p-6 bg-muted">
          <h3 className="font-semibold text-foreground mb-4">Instructions</h3>
          <ul className="text-sm text-muted-foreground space-y-2">
            <li>• Enter your staff ID at the top of the form</li>
            <li>• Use a barcode scanner or enter ticket IDs manually</li>
            <li>• Green confirmation indicates a valid, unscanned ticket</li>
            <li>• Yellow warnings indicate tickets that may have issues</li>
            <li>• Red alerts indicate invalid or already-scanned tickets</li>
          </ul>
        </Card>
      </div>
    </main>
  )
}

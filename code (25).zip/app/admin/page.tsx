"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Header from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts"
import { LogOut, Users, ShoppingCart, DollarSign, TrendingUp } from "lucide-react"
import Link from "next/link"

interface AdminDashboardStats {
  totalOrders: number
  totalRevenue: number
  totalTicketsSold: number
  conversionRate: number
}

export default function AdminDashboard() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState("")
  const [stats, setStats] = useState<AdminDashboardStats>({
    totalOrders: 0,
    totalRevenue: 0,
    totalTicketsSold: 0,
    conversionRate: 0,
  })
  const [revenueData, setRevenueData] = useState<Array<{ date: string; revenue: number }>>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const adminAuth = sessionStorage.getItem("adminAuthenticated")
    if (adminAuth === "true") {
      setIsAuthenticated(true)
      loadDashboardData()
    } else {
      setIsLoading(false)
    }
  }, [])

  const loadDashboardData = () => {
    const orders = JSON.parse(localStorage.getItem("orders") || "[]")

    const totalOrders = orders.length
    const totalRevenue = orders.reduce((sum: number, order: any) => sum + order.total, 0)
    const totalTicketsSold = orders.reduce((sum: number, order: any) => {
      return sum + order.items.reduce((itemSum: number, item: any) => itemSum + item.quantity, 0)
    }, 0)

    const conversionRate = totalOrders > 0 ? 45.2 : 0

    setStats({
      totalOrders,
      totalRevenue,
      totalTicketsSold,
      conversionRate,
    })

    // Generate revenue trend data
    const last7Days = []
    for (let i = 6; i >= 0; i--) {
      const date = new Date()
      date.setDate(date.getDate() - i)
      const dateStr = date.toLocaleDateString("en-US", { month: "short", day: "numeric" })

      const dayRevenue = orders
        .filter((order: any) => {
          const orderDate = new Date(order.orderDate)
          return orderDate.toLocaleDateString() === date.toLocaleDateString()
        })
        .reduce((sum: number, order: any) => sum + order.total, 0)

      last7Days.push({
        date: dateStr,
        revenue: dayRevenue,
      })
    }
    setRevenueData(last7Days)
    setIsLoading(false)
  }

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (password === "admin123") {
      sessionStorage.setItem("adminAuthenticated", "true")
      setIsAuthenticated(true)
      loadDashboardData()
    } else {
      alert("Invalid password")
    }
  }

  const handleLogout = () => {
    sessionStorage.removeItem("adminAuthenticated")
    setIsAuthenticated(false)
  }

  if (isLoading) {
    return (
      <main className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-24 text-center">
          <p className="text-muted-foreground">Loading admin dashboard...</p>
        </div>
      </main>
    )
  }

  if (!isAuthenticated) {
    return (
      <main className="min-h-screen bg-background">
        <Header />
        <div className="max-w-md mx-auto px-4 py-24">
          <Card className="p-8 border-border">
            <h1 className="text-3xl font-bold text-foreground mb-2">Admin Access</h1>
            <p className="text-muted-foreground mb-6">Enter the admin password to continue</p>

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label htmlFor="password" className="text-sm font-medium text-foreground">
                  Password
                </label>
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full mt-2 px-4 py-2 border border-border rounded-lg bg-card text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                  placeholder="Enter password"
                />
              </div>
              <Button type="submit" className="w-full bg-accent text-accent-foreground hover:bg-accent/90">
                Access Dashboard
              </Button>
            </form>

            <p className="text-xs text-muted-foreground mt-6 text-center">
              Demo password: <code className="bg-card px-2 py-1 rounded">admin123</code>
            </p>
          </Card>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-foreground text-balance">Admin Dashboard</h1>
            <p className="text-muted-foreground mt-2">Manage events and view business analytics</p>
          </div>
          <Button variant="outline" onClick={handleLogout} className="flex items-center gap-2 bg-transparent">
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <KPICard icon={ShoppingCart} label="Total Orders" value={stats.totalOrders} change="+12.5%" />
          <KPICard icon={DollarSign} label="Total Revenue" value={`$${stats.totalRevenue.toFixed(2)}`} change="+8.2%" />
          <KPICard icon={TrendingUp} label="Tickets Sold" value={stats.totalTicketsSold} change="+15.3%" />
          <KPICard icon={Users} label="Conversion Rate" value={`${stats.conversionRate.toFixed(1)}%`} change="+3.1%" />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Revenue Trend */}
          <Card className="p-6 border-border">
            <h3 className="text-lg font-bold text-foreground mb-6">Revenue Trend (Last 7 Days)</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="date" stroke="var(--color-muted-foreground)" />
                <YAxis stroke="var(--color-muted-foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--color-card)",
                    border: `1px solid var(--color-border)`,
                    borderRadius: "8px",
                  }}
                  formatter={(value: any) => `$${value.toFixed(2)}`}
                />
                <Line type="monotone" dataKey="revenue" stroke="var(--color-accent)" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          {/* Order Distribution */}
          <Card className="p-6 border-border">
            <h3 className="text-lg font-bold text-foreground mb-6">Ticket Type Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={getTicketDistribution()}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="type" stroke="var(--color-muted-foreground)" />
                <YAxis stroke="var(--color-muted-foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--color-card)",
                    border: `1px solid var(--color-border)`,
                    borderRadius: "8px",
                  }}
                />
                <Bar dataKey="count" fill="var(--color-accent)" />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Navigation Links */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Link href="/admin/events" className="block">
            <Card className="p-6 border-border hover:border-accent/50 transition cursor-pointer">
              <h3 className="text-lg font-bold text-foreground mb-2">Manage Events</h3>
              <p className="text-muted-foreground">View and edit event details</p>
            </Card>
          </Link>

          <Link href="/admin/orders" className="block">
            <Card className="p-6 border-border hover:border-accent/50 transition cursor-pointer">
              <h3 className="text-lg font-bold text-foreground mb-2">View Orders</h3>
              <p className="text-muted-foreground">See all customer orders and details</p>
            </Card>
          </Link>

          <Link href="/admin/analytics" className="block">
            <Card className="p-6 border-border hover:border-accent/50 transition cursor-pointer">
              <h3 className="text-lg font-bold text-foreground mb-2">Analytics</h3>
              <p className="text-muted-foreground">Detailed business insights and reports</p>
            </Card>
          </Link>
        </div>
      </div>
    </main>
  )
}

interface KPICardProps {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string | number
  change: string
}

function KPICard({ icon: Icon, label, value, change }: KPICardProps) {
  return (
    <Card className="p-6 border-border">
      <div className="flex items-start justify-between mb-4">
        <div>
          <p className="text-sm text-muted-foreground mb-1">{label}</p>
          <p className="text-3xl font-bold text-foreground">{value}</p>
        </div>
        <Icon className="w-8 h-8 text-accent opacity-80" />
      </div>
      <p className="text-xs text-green-600 font-semibold">{change} vs last period</p>
    </Card>
  )
}

function getTicketDistribution() {
  const orders = JSON.parse(localStorage.getItem("orders") || "[]")
  const distribution: { [key: string]: number } = {}

  orders.forEach((order: any) => {
    order.items.forEach((item: any) => {
      distribution[item.ticketType] = (distribution[item.ticketType] || 0) + item.quantity
    })
  })

  return Object.entries(distribution).map(([type, count]) => ({
    type,
    count,
  }))
}

"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Header from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function AdminAnalyticsPage() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const adminAuth = sessionStorage.getItem("adminAuthenticated")
    if (adminAuth !== "true") {
      router.push("/admin")
    } else {
      setIsAuthenticated(true)
      setIsLoading(false)
    }
  }, [router])

  if (isLoading) {
    return (
      <main className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-24 text-center">
          <p className="text-muted-foreground">Loading analytics...</p>
        </div>
      </main>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  const eventData = [
    { name: "Nashville Show", sales: 15400, tickets: 120 },
    { name: "LA Show", sales: 18600, tickets: 145 },
    { name: "NYC Show", sales: 22500, tickets: 180 },
    { name: "Dallas Show", sales: 19800, tickets: 155 },
    { name: "KC Show", sales: 16200, tickets: 130 },
  ]

  const COLORS = ["var(--color-accent)", "var(--color-primary)", "var(--color-chart-3)", "var(--color-chart-4)"]

  return (
    <main className="min-h-screen bg-background">
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="mb-8">
          <Link href="/admin">
            <Button variant="outline" className="mb-6 bg-transparent">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-4xl font-bold text-foreground text-balance">Analytics & Insights</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Sales by Event */}
          <Card className="p-6 border-border">
            <h3 className="text-lg font-bold text-foreground mb-6">Sales by Event</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={eventData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="name" stroke="var(--color-muted-foreground)" />
                <YAxis stroke="var(--color-muted-foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--color-card)",
                    border: `1px solid var(--color-border)`,
                    borderRadius: "8px",
                  }}
                  formatter={(value: any) => `$${value.toFixed(0)}`}
                />
                <Bar dataKey="sales" fill="var(--color-accent)" />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          {/* Tickets by Category */}
          <Card className="p-6 border-border">
            <h3 className="text-lg font-bold text-foreground mb-6">Ticket Type Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={[
                    { name: "General Admission", value: 45 },
                    { name: "VIP", value: 35 },
                    { name: "Premium VIP", value: 20 },
                  ]}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name} ${value}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {[0, 1, 2].map((index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--color-card)",
                    border: `1px solid var(--color-border)`,
                    borderRadius: "8px",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Insights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 border-border">
            <p className="text-sm text-muted-foreground mb-2">Average Order Value</p>
            <p className="text-3xl font-bold text-accent">$487.50</p>
            <p className="text-xs text-green-600 font-semibold mt-2">+5.2% from last period</p>
          </Card>
          <Card className="p-6 border-border">
            <p className="text-sm text-muted-foreground mb-2">Peak Sales Time</p>
            <p className="text-3xl font-bold text-accent">3-4 PM</p>
            <p className="text-xs text-muted-foreground mt-2">Most common purchase time</p>
          </Card>
          <Card className="p-6 border-border">
            <p className="text-sm text-muted-foreground mb-2">Customer Retention</p>
            <p className="text-3xl font-bold text-accent">32%</p>
            <p className="text-xs text-muted-foreground mt-2">Returning customers</p>
          </Card>
        </div>
      </div>
    </main>
  )
}

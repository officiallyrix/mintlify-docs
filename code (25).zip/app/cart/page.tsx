"use client"
import Link from "next/link"
import Header from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useCart } from "@/components/cart-context"
import { Trash2, ArrowLeft, ShoppingCart } from "lucide-react"

interface CartItem {
  id: number
  eventTitle: string
  venue: string
  date: string
  time: string
  ticketType: string
  price: number
  quantity: number
}

export default function CartPage() {
  const { items, removeItem, updateQuantity } = useCart()

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const fees = subtotal * 0.1
  const total = subtotal + fees

  if (items.length === 0) {
    return (
      <main className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-24 text-center">
          <ShoppingCart className="w-24 h-24 text-muted-foreground mx-auto mb-6 opacity-50" />
          <h1 className="text-4xl font-bold text-foreground mb-4">Your Cart is Empty</h1>
          <p className="text-muted-foreground mb-8">No tickets in your cart yet.</p>
          <Link href="/">
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Continue Shopping
            </Button>
          </Link>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-12">
        <Link href="/">
          <Button variant="outline" className="mb-6 bg-transparent">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Events
          </Button>
        </Link>
        <h1 className="text-4xl font-bold text-foreground text-balance mb-8">Your Cart</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <Card key={item.id} className="p-6 border-border">
                <div className="flex justify-between items-start mb-4 gap-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-foreground mb-1">{item.eventTitle}</h3>
                    <p className="text-sm text-muted-foreground">{item.venue}</p>
                    <p className="text-sm text-muted-foreground">
                      {item.date} at {item.time}
                    </p>
                    <p className="text-sm font-semibold text-accent mt-2">{item.ticketType}</p>
                  </div>
                  <button
                    onClick={() => removeItem(item.id)}
                    className="text-destructive hover:text-destructive/80 transition"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>

                <div className="flex justify-between items-center pt-4 border-t border-border">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="w-8 h-8 border border-border rounded hover:bg-accent/10 transition text-sm"
                    >
                      −
                    </button>
                    <span className="w-8 text-center text-foreground font-semibold">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="w-8 h-8 border border-border rounded hover:bg-accent/10 transition text-sm"
                    >
                      +
                    </button>
                  </div>
                  <span className="text-lg font-bold text-accent">${(item.price * item.quantity).toFixed(2)}</span>
                </div>
              </Card>
            ))}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <Card className="p-6 sticky top-24 border-border">
              <h3 className="text-2xl font-bold text-foreground mb-6">Order Summary</h3>
              <div className="space-y-4 mb-6">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="text-foreground font-semibold">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Fees (10%)</span>
                  <span className="text-foreground font-semibold">${fees.toFixed(2)}</span>
                </div>
                <div className="border-t border-border pt-4 flex justify-between">
                  <span className="text-foreground font-bold">Total</span>
                  <span className="text-foreground font-bold text-lg">${total.toFixed(2)}</span>
                </div>
              </div>
              <Link href="/checkout" className="w-full">
                <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90 py-6 text-lg">
                  Proceed to Checkout
                </Button>
              </Link>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}

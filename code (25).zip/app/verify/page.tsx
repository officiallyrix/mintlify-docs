"use client"

import type React from "react"

import { useState } from "react"
import Header from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { CheckCircle2, XCircle, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function VerifyTicketPage() {
  const [ticketId, setTicketId] = useState("")
  const [verificationResult, setVerificationResult] = useState<{
    valid: boolean
    message: string
    ticketType?: string
    event?: string
    holder?: string
  } | null>(null)
  const [isVerifying, setIsVerifying] = useState(false)

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsVerifying(true)

    // Simulate verification
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Mock verification (in real app, this would check against a database)
    const orders = JSON.parse(localStorage.getItem("orders") || "[]")
    let ticketFound = false

    for (const order of orders) {
      if (order.confirmationNumber === ticketId.split("-")[0]) {
        ticketFound = true
        setVerificationResult({
          valid: true,
          message: "Ticket is valid and ready for entry",
          ticketType: order.items[0]?.ticketType || "General Admission",
          event: order.items[0]?.title || "Morgan Wallen Live",
          holder: order.customerName,
        })
        break
      }
    }

    if (!ticketFound) {
      setVerificationResult({
        valid: false,
        message: "Ticket not found. Please check the ticket ID and try again.",
      })
    }

    setIsVerifying(false)
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />
      <div className="max-w-2xl mx-auto px-4 py-12">
        <div className="mb-8">
          <Link href="/">
            <Button variant="outline" className="mb-6 bg-transparent">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-4xl font-bold text-foreground text-balance">Verify Ticket</h1>
          <p className="text-muted-foreground mt-2">Enter a ticket ID to verify its validity</p>
        </div>

        <Card className="p-8 border-border">
          <form onSubmit={handleVerify} className="space-y-6">
            <div>
              <Label htmlFor="ticketId" className="text-foreground">
                Ticket ID
              </Label>
              <Input
                id="ticketId"
                placeholder="e.g., MWALL12345678-T1"
                value={ticketId}
                onChange={(e) => setTicketId(e.target.value)}
                className="mt-2"
                required
              />
              <p className="text-xs text-muted-foreground mt-2">
                You can find your ticket ID on your ticket or confirmation email
              </p>
            </div>

            <Button
              type="submit"
              disabled={isVerifying}
              className="w-full bg-accent text-accent-foreground hover:bg-accent/90 py-6"
            >
              {isVerifying ? "Verifying..." : "Verify Ticket"}
            </Button>
          </form>

          {verificationResult && (
            <div className="mt-8 pt-8 border-t border-border">
              <div
                className={`flex items-start gap-4 p-6 rounded-lg ${
                  verificationResult.valid ? "bg-green-50 border border-green-200" : "bg-red-50 border border-red-200"
                }`}
              >
                {verificationResult.valid ? (
                  <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
                ) : (
                  <XCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
                )}
                <div>
                  <p className={`font-bold text-lg ${verificationResult.valid ? "text-green-900" : "text-red-900"}`}>
                    {verificationResult.message}
                  </p>
                  {verificationResult.valid && (
                    <div className="mt-4 space-y-2 text-sm">
                      <p className="text-green-800">
                        <span className="font-semibold">Event:</span> {verificationResult.event}
                      </p>
                      <p className="text-green-800">
                        <span className="font-semibold">Ticket Type:</span> {verificationResult.ticketType}
                      </p>
                      <p className="text-green-800">
                        <span className="font-semibold">Holder:</span> {verificationResult.holder}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </Card>

        <div className="mt-8 p-6 bg-card border border-border rounded-lg">
          <h3 className="font-semibold text-foreground mb-3">How it works:</h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex gap-2">
              <span className="text-accent font-bold">1.</span>
              <span>Enter your ticket ID from your confirmation email or ticket</span>
            </li>
            <li className="flex gap-2">
              <span className="text-accent font-bold">2.</span>
              <span>Our system will verify the ticket's authenticity</span>
            </li>
            <li className="flex gap-2">
              <span className="text-accent font-bold">3.</span>
              <span>You'll receive instant confirmation of ticket validity</span>
            </li>
          </ul>
        </div>
      </div>
    </main>
  )
}

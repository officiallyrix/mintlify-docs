"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import Header from "@/components/header"
import { Button } from "@/components/ui/button"
import { MerchandiseCard } from "@/components/merchandise-card"
import { useCart } from "@/components/cart-context"
import { MERCHANDISE_PRODUCTS_WITH_JERSEYS } from "@/lib/merchandise"
import { ArrowLeft, ShoppingBag } from 'lucide-react'
import type { MerchandiseProduct } from "@/lib/merchandise"

export default function MerchandisePage() {
  const { addItem } = useCart()
  const [selectedCategory, setSelectedCategory] = useState<string>("All")
  const [sortBy, setSortBy] = useState<"featured" | "price-low" | "price-high">("featured")

  // Get unique categories
  const categories = useMemo(() => {
    const cats = new Set(MERCHANDISE_PRODUCTS_WITH_JERSEYS.map((p) => p.category))
    return ["All", ...Array.from(cats).sort()]
  }, [])

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    let products = MERCHANDISE_PRODUCTS_WITH_JERSEYS

    if (selectedCategory !== "All") {
      products = products.filter((p) => p.category === selectedCategory)
    }

    // Sort
    if (sortBy === "price-low") {
      products = [...products].sort((a, b) => a.price - b.price)
    } else if (sortBy === "price-high") {
      products = [...products].sort((a, b) => b.price - a.price)
    } else if (sortBy === "featured") {
      products = [...products].sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0))
    }

    return products
  }, [selectedCategory, sortBy])

  const handleAddToCart = (product: MerchandiseProduct, color: string, size: string) => {
    addItem({
      eventId: 999, // Use special ID for merchandise
      eventTitle: product.name,
      venue: `${color} • ${size}`,
      date: "Merchandise",
      time: product.category,
      ticketType: `${color} - ${size}`,
      price: product.price,
      quantity: 1,
    })
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-b from-accent/10 to-transparent py-12 md:py-20">
        <div className="max-w-7xl mx-auto px-4">
          <Link href="/">
            <Button variant="outline" className="mb-6 bg-transparent">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>
          <div className="space-y-4">
            <h1 className="text-5xl md:text-6xl font-bold text-foreground text-balance">Official Merch Store</h1>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters */}
          <div className="lg:w-64 flex-shrink-0">
            <div className="space-y-6">
              {/* Category Filter */}
              <div>
                <h3 className="text-sm font-bold text-foreground mb-4 uppercase">Category</h3>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <button
                      key={category}
                      onClick={() => setSelectedCategory(category)}
                      className={`w-full text-left px-3 py-2 rounded text-sm transition ${
                        selectedCategory === category
                          ? "bg-accent text-accent-foreground font-semibold"
                          : "text-muted-foreground hover:text-foreground hover:bg-accent/10"
                      }`}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sort Filter */}
              <div>
                <h3 className="text-sm font-bold text-foreground mb-4 uppercase">Sort By</h3>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="w-full px-3 py-2 rounded border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent"
                >
                  <option value="featured">Featured</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                </select>
              </div>

              {/* Summary */}
              <div className="pt-6 border-t border-border">
                <p className="text-sm text-muted-foreground">
                  Showing {filteredProducts.length} of {MERCHANDISE_PRODUCTS_WITH_JERSEYS.length} products
                </p>
              </div>
            </div>
          </div>

          {/* Products Grid */}
          <div className="flex-1">
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <MerchandiseCard key={product.id} product={product} onAddToCart={handleAddToCart} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20">
                <ShoppingBag className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="text-xl font-bold text-foreground mb-2">No products found</h3>
                <p className="text-muted-foreground">Try adjusting your filters</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-accent/10 py-12 md:py-20 mt-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">New Drops Coming Soon</h2>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Sign up to be notified when new merchandise is available. Limited edition items sell out fast.
          </p>
          <Link href="/cart">
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90 px-8 py-3">
              <ShoppingBag className="w-4 h-4 mr-2" />
              View Cart
            </Button>
          </Link>
        </div>
      </section>
    </main>
  )
}

import type React from "react"
import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from 'next/font/google'
import "./globals.css"
import Header from "@/components/header"
import Footer from "@/components/footer"
import LiveChat from "@/components/live-chat"
import { CartProvider } from "@/components/cart-context"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Morgan Wallen Live 2026 - Official Tickets & Tour",
  description:
    "Official Morgan Wallen Live Tour 2026 ticketing platform. Browse events, book tickets, and join the biggest country music tour of the year.",
  keywords: "Morgan Wallen, concerts, tickets, country music, tour 2026, live events",
  authors: [{ name: "Morgan Wallen Official" }],
  creator: "Morgan Wallen Official",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://morganwallenlive.com",
    siteName: "Morgan Wallen Live",
    title: "Morgan Wallen Live 2026 - Official Tour",
    description: "Get your tickets for the biggest country music tour of 2026",
  },
  generator: "v0.app",
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  themeColor: "#d4a574",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`font-sans antialiased flex flex-col min-h-screen`}>
        <CartProvider>
          <Header />
          <main className="flex-1">{children}</main>
          <LiveChat />
          <Footer />
        </CartProvider>
      </body>
    </html>
  )
}
